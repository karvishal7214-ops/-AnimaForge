/**
 * AnimaForge — Security Middleware Stack
 * Applies: Helmet, CORS, Rate-Limiting, HPP, Sanitisation
 */
'use strict';

const helmet      = require('helmet');
const cors        = require('cors');
const rateLimit   = require('express-rate-limit');
const slowDown    = require('express-slow-down');
const mongoSanitize = require('express-mongo-sanitize');
const hpp         = require('hpp');

// ── Helmet — HTTP Security Headers ───────────────────────
const helmetConfig = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc:     ["'self'"],
      scriptSrc:      ["'self'", "'unsafe-inline'", "'unsafe-eval'", 'https://accounts.google.com', 'https://fonts.googleapis.com'],
      styleSrc:       ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com', 'https://fonts.gstatic.com'],
      fontSrc:        ["'self'", 'https://fonts.gstatic.com'],
      imgSrc:         ["'self'", 'data:', 'https:', 'blob:'],
      connectSrc:     ["'self'", 'https://accounts.google.com', 'https://oauth2.googleapis.com'],
      frameSrc:       ["'self'", 'https://accounts.google.com'],
      objectSrc:      ["'none'"],
      upgradeInsecureRequests: [],
    },
  },
  crossOriginEmbedderPolicy: false, // allow Google fonts etc
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true,
  },
  noSniff: true,
  frameguard: { action: 'deny' },
  xssFilter: true,
  hidePoweredBy: true,
  permittedCrossDomainPolicies: false,
});

// ── CORS Configuration ────────────────────────────────────
const allowedOrigins = [
  process.env.FRONTEND_URL || 'http://localhost:3000',
  'http://localhost:3000',
  'http://127.0.0.1:3000',
];

const corsConfig = cors({
  origin: (origin, callback) => {
    // Allow same-origin requests (no origin header) and whitelisted origins
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      console.warn(`[SECURITY] CORS blocked: ${origin}`);
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-CSRF-Token'],
  exposedHeaders: ['X-RateLimit-Limit', 'X-RateLimit-Remaining'],
  maxAge: 600, // pre-flight cache 10 min
});

// ── Global Rate Limiter ───────────────────────────────────
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_GLOBAL_MAX || '200'),
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'Too many requests from this IP.',
    retryAfter: '15 minutes',
    code: 'RATE_LIMIT_EXCEEDED',
  },
  skip: (req) => req.path === '/health', // allow health checks
  keyGenerator: (req) => {
    return req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip;
  },
});

// ── Auth Route Limiter (strict — brute force protection) ──
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_AUTH_MAX || '10'),
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'Too many authentication attempts.',
    retryAfter: '15 minutes',
    code: 'AUTH_RATE_LIMIT',
  },
  skipSuccessfulRequests: true, // don't count successful logins
});

// ── API Rate Limiter ──────────────────────────────────────
const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: parseInt(process.env.RATE_LIMIT_API_MAX || '100'),
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'API rate limit exceeded.',
    retryAfter: '1 minute',
    code: 'API_RATE_LIMIT',
  },
});

// ── Slow-Down Middleware (progressive delay before ban) ───
const speedLimiter = slowDown({
  windowMs: 60 * 1000,
  delayAfter: 40,      // start slowing after 40 req/min
  delayMs: (used) => (used - 40) * 200, // add 200ms per extra req
  maxDelayMs: 5000,    // max 5 seconds delay
});

// ── HPP — HTTP Parameter Pollution Protection ─────────────
const hppConfig = hpp({
  whitelist: ['category', 'tag', 'sort', 'format'], // allow array values for filters
});

// ── Input Sanitiser ───────────────────────────────────────
const sanitizeConfig = mongoSanitize({
  replaceWith: '_',
  onSanitize: ({ req, key }) => {
    const ip = req.headers['x-forwarded-for'] || req.ip;
    console.warn(`[SECURITY] NoSQL injection attempt sanitised | IP: ${ip} | Key: ${key}`);
  },
});

// ── Request Size Limiter (applied in server.js) ───────────
// express.json({ limit: '10kb' }) — prevents payload flooding

// ── Remove sensitive headers ──────────────────────────────
function removeServerHeader(req, res, next) {
  res.removeHeader('X-Powered-By');
  res.removeHeader('Server');
  next();
}

// ── Security Logger ───────────────────────────────────────
function securityLogger(req, res, next) {
  const ip  = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip;
  const ua  = req.headers['user-agent'] || 'NO-UA';
  const ts  = new Date().toISOString();

  // Log only suspicious or auth routes
  if (req.path.startsWith('/auth') || req.method !== 'GET') {
    console.log(`[REQ] ${ts} | ${req.method} ${req.path} | IP: ${ip} | UA: ${ua.slice(0, 60)}`);
  }

  res.on('finish', () => {
    if (res.statusCode >= 400) {
      console.warn(`[RESP] ${ts} | ${res.statusCode} | ${req.method} ${req.path} | IP: ${ip}`);
    }
  });

  next();
}

module.exports = {
  helmetConfig,
  corsConfig,
  globalLimiter,
  authLimiter,
  apiLimiter,
  speedLimiter,
  hppConfig,
  sanitizeConfig,
  removeServerHeader,
  securityLogger,
};
