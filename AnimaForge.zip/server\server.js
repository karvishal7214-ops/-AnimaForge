/**
 * AnimaForge — Main Server
 * Secure Express app with full security hardening
 */
'use strict';

// Load env vars first
require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const express      = require('express');
const path         = require('path');
const cookieParser = require('cookie-parser');
const compression  = require('compression');
const morgan       = require('morgan');

const {
  helmetConfig, corsConfig, globalLimiter,
  hppConfig, sanitizeConfig, removeServerHeader, securityLogger,
} = require('./middleware/security');
const { ddosProtection, injectionDetector, getBanStatus } = require('./middleware/ddos');
const { optionalAuth, refreshToken } = require('./middleware/authMiddleware');
const { router: authRouter } = require('./routes/auth');
const apiRouter  = require('./routes/api');

const app  = express();
const PORT = parseInt(process.env.PORT || '3000');

// ── Trust proxy (for rate-limit IP detection behind load balancer) ──
app.set('trust proxy', 1);

// ── PHASE 1: DDoS & Abuse Protection (first in chain) ────
app.use(ddosProtection);

// ── PHASE 2: Security Headers ─────────────────────────────
app.use(helmetConfig);
app.use(removeServerHeader);

// ── PHASE 3: CORS ─────────────────────────────────────────
app.use(corsConfig);

// ── PHASE 4: Global Rate Limiter ──────────────────────────
app.use(globalLimiter);

// ── PHASE 5: Compression ──────────────────────────────────
app.use(compression());

// ── PHASE 6: Body Parsing (with size limit) ───────────────
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(cookieParser(process.env.COOKIE_SECRET || 'animaforge-cookie-secret'));

// ── PHASE 7: HTTP Request Logger (dev only) ───────────────
if (process.env.NODE_ENV !== 'production') {
  app.use(morgan('dev'));
}
app.use(securityLogger);

// ── PHASE 8: Input Sanitisation ───────────────────────────
app.use(sanitizeConfig);
app.use(hppConfig);
app.use(injectionDetector);

// ── PHASE 9: Token Refresh Middleware ─────────────────────
app.use(refreshToken);

// ── Static Files — Serve frontend ─────────────────────────
app.use(express.static(path.join(__dirname, '..'), {
  maxAge: process.env.NODE_ENV === 'production' ? '1d' : '0',
  etag: true,
  index: 'index.html',
  dotfiles: 'deny', // never serve .env or .git
}));

// ── Health Check — No auth, no rate limit ─────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    env: process.env.NODE_ENV || 'development',
    uptime: Math.floor(process.uptime()),
  });
});

// ── Auth Routes ───────────────────────────────────────────
app.use('/auth', authRouter);

// ── API Routes ────────────────────────────────────────────
app.use('/api/animations', apiRouter);

// ── Admin: Security status (internal only) ────────────────
app.get('/admin/security', optionalAuth, (req, res) => {
  // In production, restrict to admin roles
  if (process.env.NODE_ENV === 'production' && !req.user?.isAdmin) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  res.json(getBanStatus());
});

// ── SPA Fallback — All other routes → index.html ─────────
app.get('*', (req, res) => {
  // Don't serve HTML for API paths
  if (req.path.startsWith('/api') || req.path.startsWith('/auth') || req.path.startsWith('/admin')) {
    return res.status(404).json({ error: 'Not found' });
  }
  res.sendFile(path.join(__dirname, '..', 'index.html'));
});

// ── Global Error Handler ──────────────────────────────────
app.use((err, req, res, next) => {
  // CORS error
  if (err.message === 'Not allowed by CORS') {
    return res.status(403).json({ error: 'CORS policy violation', code: 'CORS_BLOCKED' });
  }
  // JSON parse error
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Invalid JSON', code: 'INVALID_JSON' });
  }
  // Payload too large
  if (err.type === 'entity.too.large') {
    return res.status(413).json({ error: 'Payload too large', code: 'PAYLOAD_TOO_LARGE' });
  }

  console.error('[SERVER ERROR]', err.message);
  res.status(500).json({ error: 'Internal server error' });
});

// ── Start Server ──────────────────────────────────────────
const server = app.listen(PORT, () => {
  console.log('');
  console.log('  ⬡  AnimaForge Server v2.0');
  console.log('  ─────────────────────────────────');
  console.log(`  🚀  Running at: http://localhost:${PORT}`);
  console.log(`  🛡️   Security:   Active (Helmet + DDoS + Rate Limit)`);
  console.log(`  🔐  Auth:       Google OAuth 2.0`);
  console.log(`  📦  Env:        ${process.env.NODE_ENV || 'development'}`);
  console.log('  ─────────────────────────────────');
  if (!process.env.GOOGLE_CLIENT_ID || process.env.GOOGLE_CLIENT_ID === 'YOUR_GOOGLE_CLIENT_ID_HERE.apps.googleusercontent.com') {
    console.log('  ⚠️   WARNING: GOOGLE_CLIENT_ID not configured.');
    console.log('      Copy server/.env.example → .env and fill in your credentials.');
    console.log('      Google Sign-In will not work until this is done.');
  }
  console.log('');
});

// ── Graceful Shutdown ─────────────────────────────────────
function shutdown(signal) {
  console.log(`\n[SERVER] ${signal} received — shutting down gracefully...`);
  server.close(() => {
    console.log('[SERVER] All connections closed. Goodbye!');
    process.exit(0);
  });
  setTimeout(() => {
    console.error('[SERVER] Forced shutdown after timeout.');
    process.exit(1);
  }, 10000);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));
process.on('uncaughtException', (err) => {
  console.error('[UNCAUGHT]', err.message);
});
process.on('unhandledRejection', (reason) => {
  console.error('[UNHANDLED REJECTION]', reason);
});

module.exports = app;
