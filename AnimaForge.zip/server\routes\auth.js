/**
 * AnimaForge — Google OAuth Routes
 * Handles: /auth/google  /auth/google/callback  /auth/logout  /auth/me
 */
'use strict';

const express = require('express');
const router  = express.Router();
const { OAuth2Client } = require('google-auth-library');
const { signToken, cookieOptions } = require('../middleware/authMiddleware');

const CLIENT_ID     = process.env.GOOGLE_CLIENT_ID     || '';
const CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || '';
const REDIRECT_URI  = process.env.GOOGLE_REDIRECT_URI  || 'http://localhost:3000/auth/google/callback';
const FRONTEND_URL  = process.env.FRONTEND_URL          || 'http://localhost:3000';

// Simple in-memory user store (replace with MongoDB/PostgreSQL in production)
const users = new Map();

function getOAuthClient() {
  return new OAuth2Client(CLIENT_ID, CLIENT_SECRET, REDIRECT_URI);
}

// ── GET /auth/google — Redirect to Google consent ─────────
router.get('/google', (req, res) => {
  const oAuth2Client = getOAuthClient();
  const authUrl = oAuth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: [
      'https://www.googleapis.com/auth/userinfo.profile',
      'https://www.googleapis.com/auth/userinfo.email',
    ],
    prompt: 'select_account',
    state: Buffer.from(JSON.stringify({ ts: Date.now() })).toString('base64'),
  });
  res.redirect(authUrl);
});

// ── GET /auth/google/callback — Handle Google response ────
router.get('/google/callback', async (req, res) => {
  const { code, error } = req.query;

  if (error) {
    console.warn('[AUTH] Google OAuth error:', error);
    return res.redirect(`${FRONTEND_URL}?auth=error&reason=${encodeURIComponent(error)}`);
  }

  if (!code) {
    return res.redirect(`${FRONTEND_URL}?auth=error&reason=no_code`);
  }

  try {
    const oAuth2Client = getOAuthClient();

    // Exchange code for tokens
    const { tokens } = await oAuth2Client.getToken(code);
    oAuth2Client.setCredentials(tokens);

    // Verify ID token
    const ticket = await oAuth2Client.verifyIdToken({
      idToken:  tokens.id_token,
      audience: CLIENT_ID,
    });

    const payload = ticket.getPayload();
    if (!payload) throw new Error('Empty payload from Google');

    const googleId = payload['sub'];
    const email    = payload['email'];
    const name     = payload['name'];
    const picture  = payload['picture'];
    const verified = payload['email_verified'];

    if (!verified) {
      return res.redirect(`${FRONTEND_URL}?auth=error&reason=email_not_verified`);
    }

    // Find or create user
    let user = users.get(googleId);
    if (!user) {
      user = {
        id:        googleId,
        email,
        name,
        picture,
        isPremium: false,
        plan:      'free',
        joinedAt:  new Date().toISOString(),
        lastLogin: new Date().toISOString(),
      };
      users.set(googleId, user);
      console.log(`[AUTH] New user registered: ${email}`);
    } else {
      user.lastLogin = new Date().toISOString();
      user.name      = name;
      user.picture   = picture;
      users.set(googleId, user);
    }

    // Sign JWT
    const token = signToken({
      id:        user.id,
      email:     user.email,
      name:      user.name,
      picture:   user.picture,
      isPremium: user.isPremium,
      plan:      user.plan,
    });

    // Set secure HttpOnly cookie
    res.cookie('af_token', token, cookieOptions());

    // Redirect to frontend with success
    res.redirect(`${FRONTEND_URL}?auth=success`);

  } catch (err) {
    console.error('[AUTH] Google callback error:', err.message);
    res.redirect(`${FRONTEND_URL}?auth=error&reason=server_error`);
  }
});

// ── POST /auth/google/token — Verify Google ID token directly ──
// (Alternative: frontend uses Google Identity Services, sends token here)
router.post('/google/token', async (req, res) => {
  try {
    const { credential } = req.body;
    if (!credential || typeof credential !== 'string') {
      return res.status(400).json({ error: 'Missing credential' });
    }

    const oAuth2Client = getOAuthClient();
    const ticket = await oAuth2Client.verifyIdToken({
      idToken:  credential,
      audience: CLIENT_ID,
    });

    const payload = ticket.getPayload();
    if (!payload) return res.status(401).json({ error: 'Invalid token' });

    const googleId = payload['sub'];
    const email    = payload['email'];
    const name     = payload['name'];
    const picture  = payload['picture'];

    let user = users.get(googleId);
    if (!user) {
      user = { id: googleId, email, name, picture, isPremium: false, plan: 'free', joinedAt: new Date().toISOString(), lastLogin: new Date().toISOString() };
      users.set(googleId, user);
    } else {
      user.lastLogin = new Date().toISOString();
      users.set(googleId, user);
    }

    const token = signToken({ id: user.id, email, name, picture, isPremium: user.isPremium, plan: user.plan });
    res.cookie('af_token', token, cookieOptions());

    res.json({ success: true, user: { name: user.name, email: user.email, picture: user.picture, isPremium: user.isPremium, plan: user.plan } });
  } catch (err) {
    console.error('[AUTH] Token verify error:', err.message);
    res.status(401).json({ error: 'Authentication failed' });
  }
});

// ── GET /auth/me — Return current user ───────────────────
router.get('/me', (req, res) => {
  const user = req.user;
  if (!user) return res.status(401).json({ error: 'Not authenticated' });
  res.json({
    id:        user.id,
    name:      user.name,
    email:     user.email,
    picture:   user.picture,
    isPremium: user.isPremium,
    plan:      user.plan,
  });
});

// ── POST /auth/logout — Clear cookie ─────────────────────
router.post('/logout', (req, res) => {
  res.clearCookie('af_token', { path: '/' });
  res.json({ success: true, message: 'Logged out successfully' });
});

// Export users map for internal access (replace with DB in prod)
module.exports = { router, users };
