@echo off
title AnimaForge Server
color 0A
echo.
echo  =====================================
echo    ANIMAFORGE v2.0 — Starting Server
echo  =====================================
echo.

:: Check if node is installed
node -v >nul 2>&1
IF ERRORLEVEL 1 (
  echo  [ERROR] Node.js is not installed!
  echo  Please download it from https://nodejs.org
  pause
  exit /b 1
)

:: Check if .env exists, if not copy from example
IF NOT EXIST ".env" (
  echo  [SETUP] Creating .env file from template...
  copy "server\.env.example" ".env" >nul
  echo  [!] IMPORTANT: Edit .env and add your Google OAuth credentials!
  echo      Then run this file again.
  echo.
  start notepad .env
  pause
  exit /b 0
)

:: Install dependencies if node_modules doesn't exist
IF NOT EXIST "node_modules" (
  echo  [SETUP] Installing dependencies...
  npm install
  echo.
)

echo  [OK] Starting server on http://localhost:3000
echo  [OK] Press Ctrl+C to stop
echo.
node server/server.js

pause
