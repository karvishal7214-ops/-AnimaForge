/**
 * ANIMAFORGE v2.0 — main.js
 * Homepage specific logic: Interactive showcase demos & counter
 */

'use strict';

document.addEventListener('DOMContentLoaded', () => {

  // Number Counter Animation
  const stats = document.querySelectorAll('.stat-num');
  const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const target = parseInt(entry.target.dataset.target);
        let count = 0;
        const speed = target / 40;
        const updateCount = () => {
          count += speed;
          if (count < target) {
            entry.target.innerText = Math.ceil(count);
            requestAnimationFrame(updateCount);
          } else {
            entry.target.innerText = target + (target > 100 ? '+' : '');
          }
        };
        updateCount();
        statsObserver.unobserve(entry.target);
      }
    });
  });
  stats.forEach(stat => statsObserver.observe(stat));

  // ── CANVAS & INTERACTIVE DEMOS (Showcase) ─────────────
  
  // Particle BG Canvas
  const canvas = document.getElementById('particleCanvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let width, height, particles = [];
    
    function resize() {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resize);
    resize();
    
    for (let i=0; i<50; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        radius: Math.random() * 2 + 1
      });
    }
    
    function drawParticles() {
      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = 'rgba(168,85,247,0.5)';
      
      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;
        
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI*2);
        ctx.fill();
      });
      requestAnimationFrame(drawParticles);
    }
    drawParticles();
  }

  // Magnetic Button
  const magBtn = document.getElementById('magneticBtn');
  if (magBtn) {
    magBtn.addEventListener('mousemove', (e) => {
      const rect = magBtn.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width/2;
      const y = e.clientY - rect.top - rect.height/2;
      magBtn.style.transform = `translate(${x * 0.4}px, ${y * 0.4}px)`;
    });
    magBtn.addEventListener('mouseleave', () => {
      magBtn.style.transform = 'translate(0px, 0px)';
    });
  }

  // Typewriter
  const twEl = document.getElementById('typewriterEl');
  if (twEl) {
    const words = ["experiences.", "interfaces.", "magic.", "the future."];
    let wIdx = 0, charIdx = 0, isDeleting = false;
    
    function type() {
      const currentWord = words[wIdx];
      
      if (isDeleting) {
        twEl.textContent = currentWord.substring(0, charIdx - 1);
        charIdx--;
      } else {
        twEl.textContent = currentWord.substring(0, charIdx + 1);
        charIdx++;
      }
      
      let speed = isDeleting ? 50 : 100;
      
      if (!isDeleting && charIdx === currentWord.length) {
        speed = 2000; // Pause at end
        isDeleting = true;
      } else if (isDeleting && charIdx === 0) {
        isDeleting = false;
        wIdx = (wIdx + 1) % words.length;
        speed = 500; // Pause before typing new
      }
      setTimeout(type, speed);
    }
    setTimeout(type, 1000);
  }

  // Tilt Card
  const tiltCard = document.getElementById('tiltCard');
  if (tiltCard) {
    tiltCard.addEventListener('mousemove', (e) => {
      const rect = tiltCard.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const cx = rect.width / 2;
      const cy = rect.height / 2;
      const rotateX = ((y - cy) / cy) * -20;
      const rotateY = ((x - cx) / cx) * 20;
      
      tiltCard.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
      
      const glow = tiltCard.querySelector('.tilt-glow');
      if (glow) {
        glow.style.left = x - 30 + 'px';
        glow.style.top = y - 30 + 'px';
      }
    });
    tiltCard.addEventListener('mouseleave', () => {
      tiltCard.style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg)`;
    });
  }

  // Particle Burst Button
  const pbBtn = document.getElementById('particleBtn');
  if (pbBtn) {
    pbBtn.addEventListener('click', (e) => {
      const rect = pbBtn.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      
      for(let i=0; i<20; i++) {
        const p = document.createElement('div');
        p.style.position = 'fixed';
        p.style.left = cx + 'px';
        p.style.top = cy + 'px';
        p.style.width = '8px';
        p.style.height = '8px';
        p.style.backgroundColor = i%2===0 ? '#06b6d4' : '#a855f7';
        p.style.borderRadius = '50%';
        p.style.pointerEvents = 'none';
        p.style.zIndex = 1000;
        document.body.appendChild(p);
        
        const angle = Math.random() * Math.PI * 2;
        const velocity = 50 + Math.random() * 100;
        const tx = Math.cos(angle) * velocity;
        const ty = Math.sin(angle) * velocity;
        
        p.animate([
          { transform: 'translate(0,0) scale(1)', opacity: 1 },
          { transform: `translate(${tx}px, ${ty}px) scale(0)`, opacity: 0 }
        ], {
          duration: 600 + Math.random()*400,
          easing: 'cubic-bezier(0, .9, .57, 1)'
        }).onfinish = () => p.remove();
      }
    });
  }

  // Ripple Button
  const ripBtn = document.getElementById('rippleBtn');
  if (ripBtn) {
    ripBtn.addEventListener('mousedown', (e) => {
      const rect = ripBtn.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      const x = e.clientX - rect.left - size/2;
      const y = e.clientY - rect.top - size/2;
      
      const wave = document.createElement('div');
      wave.className = 'ripple-wave';
      wave.style.width = wave.style.height = size + 'px';
      wave.style.left = x + 'px';
      wave.style.top = y + 'px';
      
      ripBtn.appendChild(wave);
      setTimeout(() => wave.remove(), 600);
    });
  }

  // Matrix Rain Demo
  const matrixCanvas = document.getElementById('matrixCanvas');
  if (matrixCanvas) {
    const ctx = matrixCanvas.getContext('2d');
    let width = matrixCanvas.width = matrixCanvas.offsetWidth;
    let height = matrixCanvas.height = matrixCanvas.offsetHeight;
    
    const chars = 'アァカサタナハマヤャラワガザダバパイィキシチニヒミリヰギジヂビピウゥクスツヌフムユュルグズブヅプエェケセテネヘメレゲゼデベペオォコソトノホモヨョロゴゾドボポヴッン0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
    const fontSize = 14;
    const columns = width / fontSize;
    const drops = [];
    for(let x = 0; x < columns; x++) drops[x] = 1;
    
    function drawMatrix() {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, width, height);
      ctx.fillStyle = '#10b981'; // Matrix green
      ctx.font = fontSize + 'px monospace';
      
      for(let i = 0; i < drops.length; i++) {
        const text = chars[Math.floor(Math.random() * chars.length)];
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);
        if(drops[i] * fontSize > height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
      }
    }
    // Only run if visible to save CPU
    const matrixObserver = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if(e.isIntersecting) {
          matrixCanvas.dataset.running = 'true';
        } else {
          matrixCanvas.dataset.running = 'false';
        }
      });
    });
    matrixObserver.observe(matrixCanvas);
    
    setInterval(() => {
      if(matrixCanvas.dataset.running === 'true') drawMatrix();
    }, 50);
  }

  // Bind copy buttons in hardcoded showcase
  document.querySelectorAll('.copy-btn').forEach(btn => {
    btn.addEventListener('click', () => window.copyToClipboard(`// Implementation for ${btn.dataset.code}`));
  });

  // Code Tabs
  const codeTabs = document.querySelectorAll('.code-tab');
  const codePanels = document.querySelectorAll('.code-panel');
  
  codeTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      codeTabs.forEach(t => t.classList.remove('active'));
      codePanels.forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
    });
  });

  // Load Categories for the homepage overview grid
  async function fetchCategoriesForHome() {
    try {
      const res = await fetch('/api/animations/meta/categories');
      if (res.ok) {
        const data = await res.json();
        const catGrid = document.getElementById('catGrid');
        if (catGrid) {
          catGrid.innerHTML = data.data.map(cat => `
            <a href="/library.html?category=${cat.id}" class="cat-card" style="text-decoration:none; color:inherit; display:block;">
              <span class="cat-icon">${cat.icon}</span>
              <h3>${cat.label}</h3>
              <p>Explore ${cat.label.toLowerCase()} animations</p>
              <span class="cat-count">${cat.count} items</span>
            </a>
          `).join('');
        }
      }
    } catch (err) {
      console.error(err);
    }
  }
  fetchCategoriesForHome();

});
