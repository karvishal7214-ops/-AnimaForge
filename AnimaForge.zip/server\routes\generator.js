'use strict';

/**
 * Maps preview tags to their real HTML/CSS/JS implementations.
 * Returns a single self-contained HTML string ready for <iframe srcdoc>.
 */

const DARK_BG = '#0a0a0f';
const ACCENT = '#a855f7';
const ACCENT2 = '#6366f1';
const CYAN = '#06b6d4';
const GREEN = '#10b981';

function wrapDocument(body, style = '', script = '') {
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  html, body { width: 100%; height: 100%; overflow: hidden; background: ${DARK_BG}; font-family: system-ui, sans-serif; color: #fff; }
  ${style}
</style>
</head>
<body>
${body}
<script>
(function() {
try {
${script}
} catch(e) { console.error(e); }
})();
<\/script>
</body>
</html>`;
}

const PREVIEWS = {
  // ─── TEXT EFFECTS ───────────────────────────────────────
  glitch: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <h2 class="gt" data-text="GLITCH">GLITCH</h2>
</div>`,
    `.gt{font-size:52px;font-weight:900;color:#fff;position:relative;letter-spacing:-2px;animation:g 2.5s steps(2,end) infinite}
.gt::before,.gt::after{content:attr(data-text);position:absolute;top:0;left:0;width:100%;height:100%}
.gt::before{color:#0ff;animation:gt 2.5s steps(2,end) infinite;clip-path:polygon(0 0,100% 0,100% 35%,0 35%)}
.gt::after{color:#f0f;animation:gb 2.5s steps(2,end) infinite;clip-path:polygon(0 65%,100% 65%,100% 100%,0 100%)}
@keyframes g{0%,80%,100%{transform:translate(0)}20%{transform:translate(-3px,1px)}40%{transform:translate(3px,-1px)}60%{transform:translate(-1px,2px)}}
@keyframes gt{0%,80%,100%{transform:translate(0)}20%{transform:translate(4px,-2px)}40%{transform:translate(-4px,1px)}}
@keyframes gb{0%,80%,100%{transform:translate(0)}20%{transform:translate(-4px,2px)}40%{transform:translate(4px,-2px)}}`),

  neon: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;background:#000;">
  <span class="nt">NEON</span>
</div>`,
    `.nt{font-size:52px;font-weight:900;color:#fff;letter-spacing:6px;text-shadow:0 0 7px #fff,0 0 10px #fff,0 0 42px ${ACCENT},0 0 82px ${ACCENT};animation:nf 3s ease-in-out infinite}
@keyframes nf{0%,18%,22%,25%,53%,57%,100%{text-shadow:0 0 7px #fff,0 0 10px #fff,0 0 42px ${ACCENT},0 0 82px ${ACCENT}}20%,24%,55%{text-shadow:none}}`),

  typewriter: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div style="font-size:20px;font-weight:700;"><span style="color:#aaa;">We build </span><span id="tw" style="color:${ACCENT}"></span><span class="cur">|</span></div>
</div>`,
    `.cur{color:${ACCENT};animation:blink .8s step-end infinite}@keyframes blink{0%,100%{opacity:1}50%{opacity:0}}`,
    `const words=["experiences.","interfaces.","magic.","the future."];
let wi=0,ci=0,del=false;
function type(){const w=words[wi];
  if(del){document.getElementById('tw').textContent=w.substring(0,--ci);}else{document.getElementById('tw').textContent=w.substring(0,++ci);}
  let sp=del?50:100;
  if(!del&&ci===w.length){sp=2000;del=true;}else if(del&&ci===0){del=false;wi=(wi+1)%words.length;sp=500;}
  setTimeout(type,sp);}
setTimeout(type,800);`),

  'gradient-text': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <h2 class="gt">GRADIENT</h2>
</div>`,
    `.gt{font-size:44px;font-weight:900;background:linear-gradient(135deg,${ACCENT},${CYAN},${GREEN},${ACCENT});background-size:300%;-webkit-background-clip:text;-webkit-text-fill-color:transparent;animation:gw 4s linear infinite}
@keyframes gw{0%{background-position:0%}100%{background-position:300%}}`),

  scramble: () => wrapDocument(
    `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;height:100%;gap:8px;">
  <div id="sc" style="font-size:32px;font-weight:900;font-family:monospace;color:${ACCENT};letter-spacing:4px;">SCRAMBLE</div>
  <div style="font-size:11px;color:#666;">hover to scramble</div>
</div>`,
    ``,
    `const el=document.getElementById('sc');const orig='SCRAMBLE';const chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
let iv;
el.parentElement.addEventListener('mouseenter',()=>{let n=0;iv=setInterval(()=>{el.textContent=orig.split('').map((c,i)=>i<n?orig[i]:chars[Math.floor(Math.random()*chars.length)]).join('');if(n>=orig.length)clearInterval(iv);n++;},50);});
el.parentElement.addEventListener('mouseleave',()=>{clearInterval(iv);el.textContent=orig;});`),

  'kinetic-3d': () => wrapDocument(
    `<div id="kt" style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;perspective:600px;">
  <h2 style="font-size:40px;font-weight:900;background:linear-gradient(135deg,${ACCENT},${CYAN});-webkit-background-clip:text;-webkit-text-fill-color:transparent;transform-style:preserve-3d;transition:transform .1s;user-select:none;">KINETIC</h2>
</div>`,
    ``,
    `const c=document.getElementById('kt');const h=c.querySelector('h2');
c.addEventListener('mousemove',e=>{const r=c.getBoundingClientRect();const x=(e.clientX-r.left-r.width/2)/(r.width/2)*20;const y=(e.clientY-r.top-r.height/2)/(r.height/2)*-20;h.style.transform='perspective(600px) rotateX('+y+'deg) rotateY('+x+'deg)';});
c.addEventListener('mouseleave',()=>{h.style.transform='perspective(600px) rotateX(0) rotateY(0)';});`),

  'variable-font': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <span class="vf">BOLD</span>
</div>`,
    `.vf{font-size:56px;font-weight:100;color:#fff;letter-spacing:4px;animation:fw 3s ease-in-out infinite alternate}
@keyframes fw{from{font-weight:100;letter-spacing:10px;opacity:.5}to{font-weight:900;letter-spacing:-2px;opacity:1}}`),

  // ─── HOVER EFFECTS ──────────────────────────────────────
  tilt: () => wrapDocument(
    `<div id="tw" style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div id="tc" style="width:140px;height:140px;border-radius:20px;background:linear-gradient(135deg,rgba(168,85,247,.15),rgba(99,102,241,.15));border:1px solid rgba(168,85,247,.3);display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;transform-style:preserve-3d;transition:transform .1s;cursor:pointer;">
    <div id="tg" style="position:absolute;width:60px;height:60px;background:radial-gradient(circle,rgba(255,255,255,.4),transparent 70%);border-radius:50%;pointer-events:none;opacity:0;transition:opacity .2s;"></div>
    <div style="text-align:center;"><div style="font-size:32px;color:${ACCENT};">◈</div><div style="font-size:12px;color:#aaa;margin-top:4px;">Tilt Me</div></div>
  </div>
</div>`,
    ``,
    `const tc=document.getElementById('tc'),tg=document.getElementById('tg');
tc.addEventListener('mousemove',e=>{const r=tc.getBoundingClientRect();const x=e.clientX-r.left,y=e.clientY-r.top;const rx=((y-r.height/2)/r.height)*-30,ry=((x-r.width/2)/r.width)*30;tc.style.transform='perspective(600px) rotateX('+rx+'deg) rotateY('+ry+'deg)';tg.style.opacity=1;tg.style.left=x-30+'px';tg.style.top=y-30+'px';});
tc.addEventListener('mouseleave',()=>{tc.style.transform='perspective(600px) rotateX(0) rotateY(0)';tg.style.opacity=0;});`),

  shine: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div class="sb">✨ Hover Me</div>
</div>`,
    `.sb{padding:16px 36px;background:linear-gradient(135deg,rgba(168,85,247,.2),rgba(99,102,241,.2));border:1px solid rgba(168,85,247,.4);border-radius:14px;font-size:16px;font-weight:700;position:relative;overflow:hidden;cursor:pointer;}
.sb::after{content:'';position:absolute;top:-50%;left:-75%;width:50%;height:200%;background:linear-gradient(to right,transparent,rgba(255,255,255,.25),transparent);transform:skewX(-25deg);transition:left .5s ease}
.sb:hover::after{left:150%}`),

  'reveal-slide': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div class="rs"><div class="rs-top">◈ Card</div><div class="rs-reveal">Secret content revealed!</div></div>
</div>`,
    `.rs{width:160px;height:120px;border-radius:16px;background:linear-gradient(135deg,rgba(168,85,247,.15),rgba(99,102,241,.15));border:1px solid rgba(168,85,247,.3);overflow:hidden;position:relative;cursor:pointer;}
.rs-top{display:flex;align-items:center;justify-content:center;height:100%;font-size:18px;font-weight:700;}
.rs-reveal{position:absolute;bottom:-100%;left:0;width:100%;height:100%;background:linear-gradient(135deg,${ACCENT},${ACCENT2});display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:600;text-align:center;padding:12px;transition:bottom .4s cubic-bezier(.4,0,.2,1);}
.rs:hover .rs-reveal{bottom:0}`),

  'liquid-fill': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div class="lf"><span>Fill Me</span><div class="lf-fill"></div></div>
</div>`,
    `.lf{padding:14px 32px;border-radius:50px;border:2px solid ${ACCENT};font-size:15px;font-weight:700;position:relative;overflow:hidden;cursor:pointer;color:${ACCENT}}
.lf-fill{position:absolute;bottom:-100%;left:0;width:100%;height:100%;background:linear-gradient(135deg,${ACCENT},${ACCENT2});transition:bottom .4s cubic-bezier(.4,0,.2,1);z-index:-1}
.lf span{position:relative;z-index:1;transition:color .4s}
.lf:hover .lf-fill{bottom:0}
.lf:hover span{color:#fff}`),

  'border-trace': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div class="bt">Border Trace</div>
</div>`,
    `.bt{padding:14px 32px;font-size:16px;font-weight:700;border-radius:12px;position:relative;cursor:pointer;color:#fff;background:transparent}
.bt::before,.bt::after{content:'';position:absolute;width:0;height:2px;background:${ACCENT};transition:width .3s ease}
.bt::before{top:0;left:0}.bt::after{bottom:0;right:0}
.bt:hover::before,.bt:hover::after{width:100%}`),

  'image-zoom': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div class="iz"><div class="iz-img"></div><div class="iz-label">Zoom Reveal</div></div>
</div>`,
    `.iz{width:160px;height:110px;border-radius:16px;overflow:hidden;position:relative;cursor:pointer;}
.iz-img{width:100%;height:100%;background:linear-gradient(135deg,${ACCENT},${ACCENT2},${CYAN});transform:scale(1);transition:transform .5s cubic-bezier(.4,0,.2,1);}
.iz:hover .iz-img{transform:scale(1.2)}
.iz-label{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;background:rgba(0,0,0,.3);transition:opacity .3s;}
.iz:hover .iz-label{opacity:0}`),

  // ─── LOADING STATES ─────────────────────────────────────
  spinner: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div class="st"><div class="s s1"></div><div class="s s2"></div><div class="s s3"></div></div>
</div>`,
    `.st{position:relative;width:80px;height:80px}
.s{position:absolute;inset:0;border-radius:50%;border:3px solid transparent;animation:sp 1.4s ease-in-out infinite}
.s1{border-top-color:${ACCENT}}.s2{inset:10px;border-top-color:${ACCENT2};animation-duration:1.1s;animation-direction:reverse}.s3{inset:20px;border-top-color:${CYAN};animation-duration:.8s}
@keyframes sp{to{transform:rotate(360deg)}}`),

  skeleton: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div class="sk"><div class="av"></div><div class="lines"><div class="ln lw"></div><div class="ln lm"></div><div class="ln ls"></div></div></div>
</div>`,
    `.sk{display:flex;gap:12px;align-items:flex-start;padding:18px;background:rgba(255,255,255,.03);border-radius:14px;border:1px solid rgba(255,255,255,.07);width:210px}
.av{width:44px;height:44px;border-radius:50%;background:linear-gradient(90deg,rgba(255,255,255,.06) 25%,rgba(255,255,255,.12) 50%,rgba(255,255,255,.06) 75%);background-size:200% 100%;animation:sh 1.5s ease infinite;flex-shrink:0}
.lines{flex:1;display:flex;flex-direction:column;gap:8px}
.ln{height:10px;border-radius:5px;background:linear-gradient(90deg,rgba(255,255,255,.06) 25%,rgba(255,255,255,.12) 50%,rgba(255,255,255,.06) 75%);background-size:200% 100%;animation:sh 1.5s ease infinite}
.lw{width:100%}.lm{width:75%;animation-delay:.1s}.ls{width:50%;animation-delay:.2s}
@keyframes sh{0%{background-position:200% 0}100%{background-position:-200% 0}}`),

  'dot-pulse': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;gap:10px;">
  <div class="dp"></div><div class="dp" style="animation-delay:.2s"></div><div class="dp" style="animation-delay:.4s"></div>
</div>`,
    `.dp{width:16px;height:16px;border-radius:50%;background:${ACCENT};animation:pulse 1.2s ease-in-out infinite}
@keyframes pulse{0%,100%{transform:scale(.6);opacity:.4}50%{transform:scale(1);opacity:1}}`),

  progress: () => wrapDocument(
    `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;height:100%;gap:16px;">
  <div style="font-size:13px;color:#aaa;">Loading...</div>
  <div style="width:200px;height:6px;background:rgba(255,255,255,.1);border-radius:3px;overflow:hidden;">
    <div class="pb"></div>
  </div>
  <div id="pct" style="font-size:13px;font-weight:700;color:${ACCENT};">0%</div>
</div>`,
    `.pb{height:100%;border-radius:3px;background:linear-gradient(90deg,${ACCENT},${CYAN});width:0%;transition:width .1s linear}`,
    `let p=0;const pb=document.querySelector('.pb'),pct=document.getElementById('pct');
const iv=setInterval(()=>{p=(p+1)%101;pb.style.width=p+'%';pct.textContent=p+'%';},30);`),

  'circular-progress': () => wrapDocument(
    `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;height:100%;gap:8px;">
  <svg width="80" height="80" viewBox="0 0 80 80">
    <circle cx="40" cy="40" r="32" fill="none" stroke="rgba(255,255,255,.08)" stroke-width="6"/>
    <circle id="cp" cx="40" cy="40" r="32" fill="none" stroke="${ACCENT}" stroke-width="6" stroke-linecap="round" stroke-dasharray="201" stroke-dashoffset="201" transform="rotate(-90 40 40)"/>
  </svg>
  <div id="cpct" style="font-size:13px;font-weight:700;color:${ACCENT};">0%</div>
</div>`,
    ``,
    `let p=0;const cp=document.getElementById('cp'),cpct=document.getElementById('cpct');
const iv=setInterval(()=>{p=(p+1)%101;const offset=201-(201*p/100);cp.setAttribute('stroke-dashoffset',offset);cpct.textContent=p+'%';},30);`),

  'morph-loader': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <svg width="70" height="70" viewBox="0 0 100 100"><polygon id="mp" points="50,10 90,90 10,90" fill="${ACCENT}"/></svg>
</div>`,
    ``,
    `const shapes={triangle:'50,10 90,90 10,90',square:'15,15 85,15 85,85 15,85',pentagon:'50,5 95,35 78,90 22,90 5,35'};
const keys=Object.keys(shapes);let idx=0;const mp=document.getElementById('mp');
function morph(){idx=(idx+1)%keys.length;mp.setAttribute('points',shapes[keys[idx]]);}
setInterval(morph,800);`),

  heartbeat: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <svg width="240" height="80" viewBox="0 0 240 80">
    <polyline id="hb" points="" fill="none" stroke="${GREEN}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</div>`,
    ``,
    `const hb=document.getElementById('hb');let t=0;
function draw(){t+=2;const pts=[];for(let x=0;x<=240;x+=4){const rel=(x+t)%240;let y=40;if(rel>80&&rel<100){y=40-(rel-80)*3;}else if(rel>=100&&rel<110){y=40+20;}else if(rel>=110&&rel<130){y=40-(rel-110)*1.5;}else if(rel>=130&&rel<140){y=40+15;}pts.push(x+','+y);}hb.setAttribute('points',pts.join(' '));requestAnimationFrame(draw);}draw();`),

  // ─── CANVAS / PARTICLE EFFECTS ──────────────────────────
  matrix: () => wrapDocument(
    `<canvas id="mc" style="width:100%;height:100%;display:block;"></canvas>`,
    ``,
    `const c=document.getElementById('mc');const ctx=c.getContext('2d');
c.width=c.offsetWidth;c.height=c.offsetHeight;
const chars='アカサタナハマヤラワ01ガザダバパ'.split('');const fs=14;const cols=c.width/fs;const drops=Array(Math.floor(cols)).fill(1);
function draw(){ctx.fillStyle='rgba(0,0,0,.05)';ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle='#10b981';ctx.font=fs+'px monospace';drops.forEach((y,i)=>{ctx.fillText(chars[Math.floor(Math.random()*chars.length)],i*fs,y*fs);if(y*fs>c.height&&Math.random()>.975)drops[i]=0;drops[i]++;});}
setInterval(draw,50);`),

  particle: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <button id="pb" style="padding:14px 32px;background:linear-gradient(135deg,${CYAN},${ACCENT2});border-radius:100px;color:#fff;font-size:15px;font-weight:700;border:none;cursor:pointer;transition:transform .2s;">Click Me!</button>
</div>`,
    ``,
    `const pb=document.getElementById('pb');
pb.addEventListener('click',()=>{const r=pb.getBoundingClientRect();const cx=r.left+r.width/2,cy=r.top+r.height/2;for(let i=0;i<20;i++){const p=document.createElement('div');Object.assign(p.style,{position:'fixed',left:cx+'px',top:cy+'px',width:'8px',height:'8px',background:i%2?'${CYAN}':'${ACCENT}',borderRadius:'50%',pointerEvents:'none',zIndex:9999});document.body.appendChild(p);const a=Math.random()*Math.PI*2,v=50+Math.random()*100;p.animate([{transform:'translate(0,0) scale(1)',opacity:1},{transform:'translate('+(Math.cos(a)*v)+'px,'+(Math.sin(a)*v)+'px) scale(0)',opacity:0}],{duration:700,easing:'cubic-bezier(0,.9,.57,1)'}).onfinish=()=>p.remove();}});`),

  magnetic: () => wrapDocument(
    `<div id="mw" style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <button id="mb" style="padding:16px 36px;background:linear-gradient(135deg,${ACCENT},${ACCENT2});border-radius:50px;color:#fff;font-size:16px;font-weight:700;border:none;cursor:pointer;transition:transform .3s cubic-bezier(.4,0,.2,1);box-shadow:0 10px 40px rgba(168,85,247,.4);">Magnetic</button>
</div>`,
    ``,
    `const mb=document.getElementById('mb');
mb.addEventListener('mousemove',e=>{const r=mb.getBoundingClientRect();const x=e.clientX-r.left-r.width/2;const y=e.clientY-r.top-r.height/2;mb.style.transform='translate('+(x*.4)+'px,'+(y*.4)+'px)';});
mb.addEventListener('mouseleave',()=>{mb.style.transform='translate(0,0)';});`),

  spring: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div id="sb" style="width:70px;height:70px;border-radius:18px;background:linear-gradient(135deg,${ACCENT},${ACCENT2});cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:28px;">⬡</div>
</div>`,
    ``,
    `const sb=document.getElementById('sb');
sb.addEventListener('click',()=>{sb.style.transition='transform .1s';sb.style.transform='scale(.85)';setTimeout(()=>{sb.style.transition='transform .6s cubic-bezier(.34,1.56,.64,1)';sb.style.transform='scale(1)';},100);});`),

  elastic: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div id="eb" style="width:100px;height:40px;border-radius:50px;background:linear-gradient(135deg,${ACCENT},${ACCENT2});cursor:pointer;transition:transform .6s cubic-bezier(.34,1.56,.64,1);"></div>
</div>`,
    ``,
    `const eb=document.getElementById('eb');
eb.addEventListener('mouseenter',()=>eb.style.transform='scaleX(1.3) scaleY(.8)');
eb.addEventListener('mouseleave',()=>eb.style.transform='scaleX(1) scaleY(1)');`),

  // ─── SCROLL ANIMATIONS ──────────────────────────────────
  split: () => wrapDocument(
    `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;height:100%;gap:8px;" id="sw">
  <div style="overflow:hidden;"><div class="sw" style="animation-delay:.1s">WORD</div></div>
  <div style="overflow:hidden;"><div class="sw" style="animation-delay:.25s">BY</div></div>
  <div style="overflow:hidden;"><div class="sw" style="animation-delay:.4s">WORD</div></div>
</div>`,
    `.sw{font-size:36px;font-weight:900;color:${ACCENT};animation:sr .7s cubic-bezier(.4,0,.2,1) both}
@keyframes sr{from{transform:translateY(100%);opacity:0}to{transform:translateY(0);opacity:1}}`),

  parallax: () => wrapDocument(
    `<div id="pw" style="width:100%;height:100%;overflow:hidden;position:relative;cursor:ns-resize;">
  <div id="pl" style="position:absolute;inset:-30%;background:linear-gradient(135deg,rgba(168,85,247,.3),rgba(6,182,212,.2));border-radius:50%;width:80%;height:80%;left:10%;top:10%;filter:blur(40px);"></div>
  <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:700;">Parallax Layer</div>
</div>`,
    ``,
    `const pw=document.getElementById('pw'),pl=document.getElementById('pl');
pw.addEventListener('mousemove',e=>{const r=pw.getBoundingClientRect();const x=(e.clientX-r.left-r.width/2)/r.width*30;const y=(e.clientY-r.top-r.height/2)/r.height*30;pl.style.transform='translate('+x+'px,'+y+'px)';});`),

  'scroll-reveal': () => wrapDocument(
    `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;height:100%;gap:12px;">
  <div class="sr"></div><div class="sr" style="animation-delay:.15s;width:70%"></div><div class="sr" style="animation-delay:.3s;width:50%"></div>
</div>`,
    `.sr{width:85%;height:8px;border-radius:4px;background:${ACCENT};animation:rv 2s ease-in-out infinite alternate}
@keyframes rv{from{transform:scaleX(0);transform-origin:left}to{transform:scaleX(1);transform-origin:left}}`),

  'sticky-nav': () => wrapDocument(
    `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;height:100%;">
  <div class="nav">AnimaForge ✦</div>
  <div style="font-size:12px;color:#666;margin-top:8px;">Sticky Navigation Demo</div>
</div>`,
    `.nav{padding:10px 24px;background:rgba(168,85,247,.15);border:1px solid rgba(168,85,247,.3);border-radius:50px;font-size:14px;font-weight:700;animation:hb 2s ease-in-out infinite}
@keyframes hb{0%,100%{box-shadow:0 0 0 rgba(168,85,247,0)}50%{box-shadow:0 0 30px rgba(168,85,247,.5)}}`),

  // ─── BACKGROUNDS ────────────────────────────────────────
  aurora: () => wrapDocument(
    `<div style="position:relative;width:100%;height:100%;overflow:hidden;display:flex;align-items:center;justify-content:center;">
  <div class="al a1"></div><div class="al a2"></div><div class="al a3"></div>
  <span style="position:relative;z-index:2;font-size:24px;font-weight:900;letter-spacing:3px;text-shadow:0 0 20px rgba(168,85,247,.8);">AURORA</span>
</div>`,
    `.al{position:absolute;border-radius:50%;filter:blur(30px);animation:am 6s ease-in-out infinite alternate}
.a1{width:220px;height:130px;background:rgba(168,85,247,.5);top:-10%;left:-10%}
.a2{width:180px;height:100px;background:rgba(6,182,212,.4);top:30%;right:-5%;animation-delay:-2s}
.a3{width:160px;height:90px;background:rgba(16,185,129,.35);bottom:-10%;left:30%;animation-delay:-4s}
@keyframes am{from{transform:translate(0,0) scale(1)}to{transform:translate(20px,-15px) scale(1.15)}}`),

  'particle-bg': () => wrapDocument(
    `<canvas id="pc" style="width:100%;height:100%;display:block;"></canvas>`,
    ``,
    `const c=document.getElementById('pc');const ctx=c.getContext('2d');c.width=c.offsetWidth;c.height=c.offsetHeight;
const pts=Array.from({length:40},()=>({x:Math.random()*c.width,y:Math.random()*c.height,vx:(Math.random()-.5)*.5,vy:(Math.random()-.5)*.5,r:Math.random()*2+1}));
function draw(){ctx.clearRect(0,0,c.width,c.height);ctx.fillStyle='rgba(168,85,247,.5)';pts.forEach(p=>{p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>c.width)p.vx*=-1;if(p.y<0||p.y>c.height)p.vy*=-1;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();});pts.forEach((a,i)=>pts.forEach((b,j)=>{if(j<=i)return;const d=Math.hypot(a.x-b.x,a.y-b.y);if(d<100){ctx.strokeStyle='rgba(168,85,247,'+(1-d/100)*.3+')';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();}}));requestAnimationFrame(draw);}draw();`),

  'gradient-bg': () => wrapDocument(
    `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;">
  <div class="gb"></div>
  <span style="position:relative;z-index:2;font-size:18px;font-weight:700;text-shadow:0 0 20px rgba(0,0,0,.5);">Dynamic Gradient</span>
</div>`,
    `.gb{position:absolute;inset:0;background:linear-gradient(135deg,rgba(168,85,247,.4),rgba(6,182,212,.3),rgba(16,185,129,.2),rgba(168,85,247,.4));background-size:400%;animation:gs 8s ease infinite}
@keyframes gs{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}`),

  'mesh-gradient': () => wrapDocument(
    `<div style="width:100%;height:100%;position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;">
  <div class="m1"></div><div class="m2"></div><div class="m3"></div>
  <span style="position:relative;z-index:2;font-size:18px;font-weight:700;">Mesh Gradient</span>
</div>`,
    `.m1,.m2,.m3{position:absolute;border-radius:50%;filter:blur(50px)}
.m1{width:250px;height:250px;background:rgba(168,85,247,.4);top:-30%;left:-10%;animation:mf 7s ease-in-out infinite alternate}
.m2{width:200px;height:200px;background:rgba(6,182,212,.35);bottom:-20%;right:-10%;animation:mf 9s ease-in-out infinite alternate-reverse}
.m3{width:180px;height:180px;background:rgba(16,185,129,.3);top:20%;left:30%;animation:mf 5s ease-in-out infinite alternate}
@keyframes mf{from{transform:translate(0,0)}to{transform:translate(30px,-20px)}}`),

  'noise-bg': () => wrapDocument(
    `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;">
  <canvas id="nc" style="position:absolute;inset:0;width:100%;height:100%;opacity:.15;"></canvas>
  <div style="position:absolute;inset:0;background:linear-gradient(135deg,rgba(168,85,247,.3),rgba(6,182,212,.2));"></div>
  <span style="position:relative;z-index:2;font-size:18px;font-weight:700;">Grain Texture</span>
</div>`,
    ``,
    `const c=document.getElementById('nc');const ctx=c.getContext('2d');c.width=c.offsetWidth;c.height=c.offsetHeight;
function noise(){const img=ctx.createImageData(c.width,c.height);for(let i=0;i<img.data.length;i+=4){const v=Math.random()*255|0;img.data[i]=img.data[i+1]=img.data[i+2]=v;img.data[i+3]=255;}ctx.putImageData(img,0,0);}
setInterval(noise,50);`),

  // ─── 3D EFFECTS ─────────────────────────────────────────
  flip: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;perspective:600px;">
  <div class="fc">
    <div class="ff"><span style="font-size:28px;">◈</span><span style="font-size:14px;font-weight:700;">Hover Me</span></div>
    <div class="fb"><span style="font-size:28px;">✦</span><span style="font-size:14px;font-weight:700;">3D Flip!</span></div>
  </div>
</div>`,
    `.fc{width:140px;height:140px;position:relative;transform-style:preserve-3d;transition:transform .7s cubic-bezier(.4,0,.2,1);cursor:pointer}
.fc:hover{transform:rotateY(180deg)}
.ff,.fb{position:absolute;inset:0;border-radius:18px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;backface-visibility:hidden}
.ff{background:linear-gradient(135deg,rgba(168,85,247,.15),rgba(99,102,241,.15));border:1px solid rgba(168,85,247,.3);color:#fff}
.fb{background:linear-gradient(135deg,${ACCENT},${ACCENT2});transform:rotateY(180deg);color:#fff}`),

  holographic: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;background:#111;">
  <div class="hc"><div class="hg"></div><div style="position:relative;z-index:2;text-align:center;"><span style="font-size:32px;display:block;margin-bottom:6px;">♦</span><p style="font-size:12px;font-weight:700;">Holographic</p></div></div>
</div>`,
    `.hc{width:130px;height:180px;border-radius:12px;position:relative;overflow:hidden;border:1px solid rgba(255,255,255,.2);background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center;cursor:pointer}
.hg{position:absolute;inset:0;background:conic-gradient(from 0deg at 50% 50%,#ff0080,#ff8c00,#40e0d0,#7b2ff7,#ff0080);opacity:0;transition:opacity .3s;mix-blend-mode:color}
.hc:hover .hg{opacity:.6;animation:hs 3s linear infinite}
@keyframes hs{to{transform:rotate(360deg) scale(2)}}`),

  'css-3d': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div class="cube-wrap"><div class="cube"><div class="face front">CSS</div><div class="face back">3D</div><div class="face left">✦</div><div class="face right">◈</div><div class="face top">⬡</div><div class="face bottom">⬢</div></div></div>
</div>`,
    `.cube-wrap{perspective:400px;width:80px;height:80px}
.cube{width:80px;height:80px;position:relative;transform-style:preserve-3d;animation:rot 6s linear infinite}
.face{position:absolute;width:80px;height:80px;border:2px solid rgba(168,85,247,.5);background:rgba(168,85,247,.08);display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:900;color:${ACCENT};backface-visibility:visible}
.front{transform:translateZ(40px)}.back{transform:rotateY(180deg) translateZ(40px)}.left{transform:rotateY(-90deg) translateZ(40px)}.right{transform:rotateY(90deg) translateZ(40px)}.top{transform:rotateX(90deg) translateZ(40px)}.bottom{transform:rotateX(-90deg) translateZ(40px)}
@keyframes rot{from{transform:rotateX(-15deg) rotateY(0)}to{transform:rotateX(-15deg) rotateY(360deg)}}`),

  'perspective-tilt': () => wrapDocument(
    `<div id="pt" style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;perspective:600px;">
  <div id="ptc" style="width:180px;height:120px;border-radius:16px;background:linear-gradient(135deg,rgba(168,85,247,.2),rgba(6,182,212,.15));border:1px solid rgba(168,85,247,.3);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:15px;cursor:pointer;transform-style:preserve-3d;transition:transform .15s;">3D Perspective</div>
</div>`,
    ``,
    `const ptc=document.getElementById('ptc'),pt=document.getElementById('pt');
pt.addEventListener('mousemove',e=>{const r=ptc.getBoundingClientRect();const x=(e.clientX-r.left-r.width/2)/(r.width/2)*20;const y=(e.clientY-r.top-r.height/2)/(r.height/2)*-20;ptc.style.transform='perspective(600px) rotateX('+y+'deg) rotateY('+x+'deg)';});
pt.addEventListener('mouseleave',()=>{ptc.style.transform='perspective(600px) rotateX(0) rotateY(0)';});`),

  // ─── MICRO-INTERACTIONS ─────────────────────────────────
  ripple: () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <button id="rb" style="padding:14px 32px;background:linear-gradient(135deg,${GREEN},${CYAN});border-radius:100px;color:#fff;font-size:15px;font-weight:700;border:none;cursor:pointer;position:relative;overflow:hidden;">Ripple Click</button>
</div>`,
    `.rw{position:absolute;border-radius:50%;background:rgba(255,255,255,.4);transform:scale(0);animation:ra .6s linear;pointer-events:none}
@keyframes ra{to{transform:scale(4);opacity:0}}`,
    `const rb=document.getElementById('rb');
rb.addEventListener('mousedown',e=>{const r=rb.getBoundingClientRect();const s=Math.max(r.width,r.height);const w=document.createElement('div');w.className='rw';w.style.cssText='width:'+s+'px;height:'+s+'px;left:'+(e.clientX-r.left-s/2)+'px;top:'+(e.clientY-r.top-s/2)+'px';rb.appendChild(w);setTimeout(()=>w.remove(),600);});`),

  'gradient-border': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div class="gb"><div class="gi"><span>✦ Animated</span></div></div>
</div>`,
    `@property --angle{syntax:'<angle>';initial-value:0deg;inherits:false}
.gb{padding:3px;border-radius:16px;background:conic-gradient(from var(--angle),${ACCENT},${ACCENT2},${CYAN},${GREEN},${ACCENT});animation:sg 3s linear infinite}
@keyframes sg{to{--angle:360deg}}
.gi{background:${DARK_BG};border-radius:14px;padding:18px 36px;font-size:18px;font-weight:700}`),

  'button-morph': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;gap:16px;flex-direction:column;">
  <button id="bm" style="padding:14px 36px;background:linear-gradient(135deg,${ACCENT},${ACCENT2});border-radius:50px;color:#fff;font-size:15px;font-weight:700;border:none;cursor:pointer;transition:all .4s cubic-bezier(.4,0,.2,1);">Click Me</button>
  <div style="font-size:11px;color:#666;">Click to morph</div>
</div>`,
    ``,
    `const bm=document.getElementById('bm');let st=false;
bm.addEventListener('click',()=>{if(!st){bm.style.borderRadius='8px';bm.style.transform='scale(1.1)';bm.textContent='Morphed!';bm.style.background='linear-gradient(135deg,${CYAN},${GREEN})';}else{bm.style.borderRadius='50px';bm.style.transform='scale(1)';bm.textContent='Click Me';bm.style.background='linear-gradient(135deg,${ACCENT},${ACCENT2})';}st=!st;});`),

  'hover-glow': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div class="hg">✨ Glow Effect</div>
</div>`,
    `.hg{padding:16px 36px;border-radius:14px;background:rgba(168,85,247,.1);border:1px solid rgba(168,85,247,.3);font-size:15px;font-weight:700;cursor:pointer;transition:all .3s;color:#fff}
.hg:hover{box-shadow:0 0 30px rgba(168,85,247,.6),0 0 60px rgba(168,85,247,.3);border-color:${ACCENT};background:rgba(168,85,247,.2);transform:scale(1.05)}`),

  'click-spark': () => wrapDocument(
    `<div id="cs" style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;cursor:pointer;">
  <span style="font-size:14px;color:#666;">Click anywhere</span>
</div>`,
    ``,
    `document.getElementById('cs').addEventListener('click',e=>{for(let i=0;i<12;i++){const s=document.createElement('div');Object.assign(s.style,{position:'fixed',left:e.clientX+'px',top:e.clientY+'px',width:'6px',height:'6px',background:'hsl('+(Math.random()*60+240)+',100%,70%)',borderRadius:'50%',pointerEvents:'none',zIndex:9999});document.body.appendChild(s);const a=Math.random()*Math.PI*2,v=30+Math.random()*80;s.animate([{transform:'translate(-50%,-50%) scale(1)',opacity:1},{transform:'translate(calc(-50% + '+(Math.cos(a)*v)+'px),calc(-50% + '+(Math.sin(a)*v)+'px)) scale(0)',opacity:0}],{duration:500,easing:'cubic-bezier(0,.9,.57,1)'}).onfinish=()=>s.remove();}});`),

  // ─── SPECIAL / CANVAS EFFECTS ───────────────────────────
  'fluid': () => wrapDocument(
    `<div style="width:100%;height:100%;position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;">
  <div class="fb1"></div><div class="fb2"></div><div class="fb3"></div>
</div>`,
    `.fb1,.fb2,.fb3{position:absolute;border-radius:50%;filter:blur(25px)}
.fb1{width:120px;height:120px;background:rgba(168,85,247,.6);top:10%;left:10%;animation:fm 4s ease-in-out infinite alternate}
.fb2{width:100px;height:100px;background:rgba(6,182,212,.5);top:20%;right:15%;animation:fm 4s ease-in-out infinite alternate-reverse;animation-delay:-1.5s}
.fb3{width:80px;height:80px;background:rgba(16,185,129,.4);bottom:15%;left:40%;animation:fm 4s ease-in-out infinite alternate;animation-delay:-3s}
@keyframes fm{0%{transform:translate(0,0)}33%{transform:translate(30px,-20px)}66%{transform:translate(-20px,25px)}100%{transform:translate(15px,-10px)}}`),

  'gravity': () => wrapDocument(
    `<div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:center;width:100%;height:100%;gap:8px;padding:16px;">
  <div class="gb">◈</div><div class="gb" style="animation-delay:-.3s">✦</div><div class="gb" style="animation-delay:-.6s">⬡</div>
  <div class="gb" style="animation-delay:-.15s">◉</div><div class="gb" style="animation-delay:-.45s">⬢</div>
</div>`,
    `.gb{width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,${ACCENT},${ACCENT2});display:flex;align-items:center;justify-content:center;font-size:18px;animation:gf 2s cubic-bezier(.4,0,.2,1) infinite alternate}
@keyframes gf{from{transform:translateY(-20px);opacity:.6}to{transform:translateY(20px);opacity:1}}`),

  'inertia': () => wrapDocument(
    `<div id="iw" style="width:100%;height:100%;position:relative;overflow:hidden;cursor:grab;">
  <div id="ib" style="position:absolute;width:50px;height:50px;border-radius:50%;background:linear-gradient(135deg,${ACCENT},${ACCENT2});top:50%;left:50%;transform:translate(-50%,-50%);box-shadow:0 0 30px rgba(168,85,247,.5);"></div>
</div>`,
    ``,
    `const iw=document.getElementById('iw'),ib=document.getElementById('ib');let x=0,y=0,vx=0,vy=0,isDragging=false,lx=0,ly=0;
const r=iw.getBoundingClientRect();x=r.width/2;y=r.height/2;
iw.addEventListener('mousedown',e=>{isDragging=true;lx=e.clientX;ly=e.clientY;vx=0;vy=0;});
document.addEventListener('mousemove',e=>{if(!isDragging)return;vx=e.clientX-lx;vy=e.clientY-ly;lx=e.clientX;ly=e.clientY;x+=vx;y+=vy;ib.style.left=x+'px';ib.style.top=y+'px';});
document.addEventListener('mouseup',()=>{isDragging=false;(function step(){vx*=.92;vy*=.92;x+=vx;y+=vy;x=Math.max(25,Math.min(iw.offsetWidth-25,x));y=Math.max(25,Math.min(iw.offsetHeight-25,y));ib.style.left=x+'px';ib.style.top=y+'px';if(Math.abs(vx)>.1||Math.abs(vy)>.1)requestAnimationFrame(step);})();});`),

  // ─── SVG / PATH ANIMATIONS ──────────────────────────────
  'svg-draw': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <svg width="120" height="120" viewBox="0 0 100 100">
    <circle cx="50" cy="50" r="40" fill="none" stroke="${ACCENT}" stroke-width="3" class="sc"/>
    <polyline points="30,50 45,65 70,35" fill="none" stroke="${GREEN}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" class="sc2"/>
  </svg>
</div>`,
    `.sc{stroke-dasharray:251;stroke-dashoffset:251;animation:sd 1.5s ease forwards}
.sc2{stroke-dasharray:60;stroke-dashoffset:60;animation:sd 1s .8s ease forwards}
@keyframes sd{to{stroke-dashoffset:0}}`),

  'morphing-svg': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <svg width="80" height="80" viewBox="0 0 100 100"><polygon id="ms" points="50,10 90,90 10,90" fill="${ACCENT}"/></svg>
</div>`,
    ``,
    `const shapes=['50,10 90,90 10,90','15,15 85,15 85,85 15,85','50,5 95,35 78,90 22,90 5,35'];let i=0;
const ms=document.getElementById('ms');setInterval(()=>{i=(i+1)%shapes.length;ms.setAttribute('points',shapes[i]);ms.style.transition='all .6s ease';},900);`),

  'liquid-svg': () => wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <svg width="120" height="120" viewBox="0 0 100 100">
    <path id="lp" d="M50,10 Q90,30 80,60 Q70,90 50,85 Q30,90 20,60 Q10,30 50,10Z" fill="${ACCENT}" opacity=".8"/>
  </svg>
</div>`,
    ``,
    `const lp=document.getElementById('lp');const shapes=['M50,10 Q90,30 80,60 Q70,90 50,85 Q30,90 20,60 Q10,30 50,10Z','M50,15 Q80,20 85,50 Q80,80 50,90 Q20,80 15,50 Q20,20 50,15Z','M50,5 Q95,25 85,65 Q65,95 50,90 Q35,95 15,65 Q5,25 50,5Z'];
let i=0;const lps=document.getElementById('lp');setInterval(()=>{i=(i+1)%shapes.length;lps.setAttribute('d',shapes[i]);lps.style.transition='d .8s ease';},1000);`),

  // ─── ADVANCED / WEBGL ───────────────────────────────────
  'webgl-shader': () => wrapDocument(
    `<canvas id="wc" style="width:100%;height:100%;display:block;"></canvas>`,
    ``,
    `const c=document.getElementById('wc');c.width=c.offsetWidth;c.height=c.offsetHeight;const gl=c.getContext('webgl');if(!gl)return;
const vs='attribute vec2 p;void main(){gl_Position=vec4(p,0,1);}';
const fs='precision mediump float;uniform float t;uniform vec2 res;void main(){vec2 uv=(gl_FragCoord.xy-.5*res)/min(res.x,res.y);float d=length(uv);vec3 col=vec3(.66+.33*sin(d*8.-t),sin(d*6.-t*.7)*.5+.5,cos(d*7.-t*.5)*.5+.5)*smoothstep(.8,0.,d);gl_FragColor=vec4(col,1.);}';
function mkShader(t,s){const sh=gl.createShader(t);gl.shaderSource(sh,s);gl.compileShader(sh);return sh;}
const prog=gl.createProgram();gl.attachShader(prog,mkShader(gl.VERTEX_SHADER,vs));gl.attachShader(prog,mkShader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(prog);gl.useProgram(prog);
const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
const loc=gl.getAttribLocation(prog,'p');gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);
const tl=gl.getUniformLocation(prog,'t'),rl=gl.getUniformLocation(prog,'res');
let s=0;(function draw(){gl.uniform1f(tl,s+=.02);gl.uniform2f(rl,c.width,c.height);gl.drawArrays(gl.TRIANGLE_STRIP,0,4);requestAnimationFrame(draw);})();`),

  'fire-effect': () => wrapDocument(
    `<canvas id="fc" style="width:100%;height:100%;display:block;"></canvas>`,
    ``,
    `const c=document.getElementById('fc');c.width=c.offsetWidth;c.height=c.offsetHeight;const ctx=c.getContext('2d');
function draw(){ctx.fillStyle='rgba(0,0,0,.08)';ctx.fillRect(0,0,c.width,c.height);for(let i=0;i<5;i++){const x=Math.random()*c.width,y=c.height,r=20+Math.random()*30;const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,'rgba(255,200,0,.9)');g.addColorStop(.4,'rgba(255,100,0,.6)');g.addColorStop(1,'rgba(255,0,0,0)');ctx.fillStyle=g;ctx.beginPath();ctx.ellipse(x,y-r*.3,r*.4,r,0,0,Math.PI*2);ctx.fill();}requestAnimationFrame(draw);}draw();`),

  'wave-effect': () => wrapDocument(
    `<canvas id="wv" style="width:100%;height:100%;display:block;"></canvas>`,
    ``,
    `const c=document.getElementById('wv');c.width=c.offsetWidth;c.height=c.offsetHeight;const ctx=c.getContext('2d');let t=0;
function draw(){ctx.clearRect(0,0,c.width,c.height);for(let i=3;i>0;i--){ctx.beginPath();ctx.moveTo(0,c.height/2);for(let x=0;x<=c.width;x+=4){const y=c.height/2+Math.sin(x*.02+t+i)*(20*i)+Math.sin(x*.04-t*.7)*(10*i);ctx.lineTo(x,y);}ctx.lineTo(c.width,c.height);ctx.lineTo(0,c.height);ctx.closePath();ctx.fillStyle='rgba(168,85,247,'+(i*.12)+')';ctx.fill();}t+=.03;requestAnimationFrame(draw);}draw();`),

  'star-field': () => wrapDocument(
    `<canvas id="sf" style="width:100%;height:100%;display:block;background:#000;"></canvas>`,
    ``,
    `const c=document.getElementById('sf');c.width=c.offsetWidth;c.height=c.offsetHeight;const ctx=c.getContext('2d');
const stars=Array.from({length:120},()=>({x:Math.random()*c.width,y:Math.random()*c.height,r:Math.random()*1.5+.3,v:Math.random()*.4+.1}));
function draw(){ctx.fillStyle='rgba(0,0,0,.1)';ctx.fillRect(0,0,c.width,c.height);stars.forEach(s=>{s.x-=s.v;if(s.x<0)s.x=c.width;ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fillStyle='rgba(255,255,255,'+(s.r/1.8)+')';ctx.fill();});requestAnimationFrame(draw);}draw();`),
};

/**
 * Get preview HTML for an animation.
 * Returns a complete self-contained HTML doc for iframe srcdoc.
 */
function getPreviewHtml(previewTag) {
  const fn = PREVIEWS[previewTag];
  if (fn) return fn();
  // Fallback: generic animated shape
  const colors = ['#a855f7','#6366f1','#06b6d4','#10b981','#f59e0b','#ef4444'];
  const c = colors[Math.abs(previewTag.split('').reduce((a,b)=>a+b.charCodeAt(0),0)) % colors.length];
  return wrapDocument(
    `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
  <div class="def"></div>
</div>`,
    `.def{width:64px;height:64px;background:${c};border-radius:16px;animation:p 2s ease-in-out infinite}
@keyframes p{0%,100%{transform:scale(1) rotate(0deg);box-shadow:0 0 20px ${c}40}50%{transform:scale(1.2) rotate(45deg);box-shadow:0 0 40px ${c}80}}`
  );
}

module.exports = { getPreviewHtml };
