/**
 * ANIMAFORGE v2.0 — shared.js
 * Shared logic across all pages: Auth, Nav, Modals, Cursor, Toast
 */

'use strict';

const API_BASE = '/api';
const AUTH_BASE = '/auth';

const sharedState = {
  user: null
};

document.addEventListener('DOMContentLoaded', () => {
  // ── DOM ELEMENTS ────────────────────────────────────────
  const navAuthContainer = document.getElementById('navAuth');
  const loginModal = document.getElementById('loginModal');
  const loginModalClose = document.getElementById('loginModalClose');
  const toast = document.getElementById('toast');
  const nav = document.getElementById('mainNav');
  
  // CTAs (may not exist on all pages)
  const heroSignIn = document.getElementById('heroSignIn');
  const freeSignIn = document.getElementById('freeSignIn');
  const ctaSignIn = document.getElementById('ctaSignIn');

  // ── AUTHENTICATION ────────────────────────────────────────
  
  async function checkSession() {
    try {
      const res = await fetch(`${AUTH_BASE}/me`);
      if (res.ok) {
        const data = await res.json();
        sharedState.user = data;
      } else {
        sharedState.user = null;
      }
    } catch (err) {
      sharedState.user = null;
    }
    updateAuthUI();
  }

  function updateAuthUI() {
    if (!navAuthContainer) return;
    
    if (sharedState.user) {
      navAuthContainer.innerHTML = `
        <div class="nav-user nav-dropdown">
          <img src="${sharedState.user.picture || 'https://via.placeholder.com/150'}" alt="${sharedState.user.name}" class="nav-avatar" referrerpolicy="no-referrer" />
          <div style="display:flex; flex-direction:column; gap:2px;">
            <span class="nav-user-name">${sharedState.user.name}</span>
          </div>
          <div class="nav-dropdown-menu">
            <button id="logoutBtn">Log out</button>
          </div>
        </div>
      `;
      document.getElementById('logoutBtn')?.addEventListener('click', handleLogout);

      if (heroSignIn) heroSignIn.style.display = 'none';
      if (freeSignIn) freeSignIn.textContent = 'Go to Library';
      if (ctaSignIn) ctaSignIn.style.display = 'none';
    } else {
      navAuthContainer.innerHTML = `<button class="btn btn-nav" id="signInNavBtn">Sign in with Google</button>`;
      document.getElementById('signInNavBtn')?.addEventListener('click', openLoginModal);

      if (heroSignIn) heroSignIn.style.display = 'inline-flex';
      if (freeSignIn) freeSignIn.textContent = 'Get Started Free';
      if (ctaSignIn) ctaSignIn.style.display = 'inline-flex';
    }
  }

  async function handleLogout() {
    try {
      await fetch(`${AUTH_BASE}/logout`, { method: 'POST' });
      sharedState.user = null;
      updateAuthUI();
      window.showToast('Logged out successfully');
    } catch (err) {
      window.showToast('Logout failed');
    }
  }

  function handleAuthCallback() {
    const params = new URLSearchParams(window.location.search);
    const authStatus = params.get('auth');
    if (authStatus === 'success') {
      window.showToast('Successfully signed in!');
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (authStatus === 'error') {
      window.showToast(`Sign in failed: ${params.get('reason')}`, 'error');
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }

  // ── MODALS ────────────────────────────────────────────────
  window.openLoginModal = function() {
    if (sharedState.user || !loginModal) return;
    loginModal.classList.add('open');
  };
  function closeLoginModal() {
    if (loginModal) loginModal.classList.remove('open');
  }

  loginModalClose?.addEventListener('click', closeLoginModal);
  window.addEventListener('click', (e) => {
    if (e.target === loginModal) closeLoginModal();
  });

  heroSignIn?.addEventListener('click', window.openLoginModal);
  freeSignIn?.addEventListener('click', (e) => {
    if(!sharedState.user) { window.openLoginModal(); e.preventDefault(); }
  });
  ctaSignIn?.addEventListener('click', window.openLoginModal);

  // ── TOAST ─────────────────────────────────────────────────
  window.showToast = function(message, type = 'success') {
    if (!toast) return;
    toast.textContent = message;
    toast.className = 'toast show ' + type;
    setTimeout(() => {
      toast.classList.remove('show');
    }, 3000);
  };

  // ── CURSOR ────────────────────────────────────────────────
  const cursor = document.getElementById('cursor');
  const cursorTrail = document.getElementById('cursorTrail');
  
  if (cursor && cursorTrail) {
    let mouseX = 0, mouseY = 0;
    let trailX = 0, trailY = 0;
    
    document.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      cursor.style.left = mouseX + 'px';
      cursor.style.top = mouseY + 'px';
    });
    
    function animateCursor() {
      trailX += (mouseX - trailX) * 0.2;
      trailY += (mouseY - trailY) * 0.2;
      cursorTrail.style.left = trailX + 'px';
      cursorTrail.style.top = trailY + 'px';
      requestAnimationFrame(animateCursor);
    }
    animateCursor();
  }

  // ── UTILITIES ─────────────────────────────────────────────
  window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
      nav?.classList.add('scrolled');
    } else {
      nav?.classList.remove('scrolled');
    }
  });

  window.copyToClipboard = function(text, successMsg = 'Code copied to clipboard!') {
    navigator.clipboard.writeText(text).then(() => {
      window.showToast(successMsg);
    }).catch(() => {
      window.showToast('Failed to copy', 'error');
    });
  };

  const revealElements = document.querySelectorAll('[data-reveal]');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: "0px 0px -50px 0px" });
  revealElements.forEach(el => revealObserver.observe(el));

  // ── QUICK VIEW MODAL ──────────────────────────────────────
  const quickViewModalHtml = `
    <div class="modal-overlay" id="quickViewModal" role="dialog" aria-modal="true">
      <div class="modal-box preview-modal">
        <div class="preview-modal-header">
          <h2 class="preview-modal-title" id="quickViewTitle">Preview</h2>
          <button class="modal-close" id="quickViewClose" aria-label="Close" style="position:static;">✕</button>
        </div>
        <div class="preview-modal-stage" id="quickViewStage">
          <!-- Injected dynamically -->
        </div>
        <div class="preview-modal-footer">
          <a href="#" id="quickViewLink" class="btn btn-primary" style="padding: 8px 24px;">View Code</a>
        </div>
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', quickViewModalHtml);

  const quickViewModal = document.getElementById('quickViewModal');
  const quickViewStage = document.getElementById('quickViewStage');
  const quickViewTitle = document.getElementById('quickViewTitle');
  const quickViewLink = document.getElementById('quickViewLink');

  document.getElementById('quickViewClose')?.addEventListener('click', () => {
    quickViewModal.classList.remove('open');
    quickViewStage.innerHTML = ''; // clear for performance
  });

  window.openPreviewModal = function(card, id) {
    if (!quickViewModal) return;
    
    const name = card.querySelector('h3').textContent;
    // We clone the innerHTML of the demo-stage, but we must remove the overlay button first
    const stageClone = card.querySelector('.demo-stage').cloneNode(true);
    const overlay = stageClone.querySelector('.demo-stage-overlay');
    if (overlay) overlay.remove();
    const html = stageClone.innerHTML;
    const js = card.dataset.rawjs || '';

    quickViewTitle.textContent = name;
    
    // Prevent ID collision between grid canvas and modal canvas
    const previewHtml = html.replace(`id="canvas-${id}"`, `id="canvas-preview-${id}"`);
    quickViewStage.innerHTML = previewHtml;
    
    quickViewLink.href = `/animation.html?id=${id}`;

    if (js && !js.includes('No JS needed')) {
      const previewJs = js.replace(`'canvas-${id}'`, `'canvas-preview-${id}'`);
      try {
        const runScript = new Function(previewJs);
        setTimeout(() => runScript(), 50);
      } catch (e) {
        console.error('Failed to run animation JS in quick view', e);
      }
    }

    quickViewModal.classList.add('open');
  };

  // Close on outside click
  window.addEventListener('click', (e) => {
    if (e.target === quickViewModal) {
      quickViewModal.classList.remove('open');
      quickViewStage.innerHTML = '';
    }
  });

  // Initialize Auth
  handleAuthCallback();
  checkSession();

  // ── PAGE TRANSITIONS ──────────────────────────────────────
  // 1. Inject transition overlay
  const overlay = document.createElement('div');
  overlay.className = 'page-transition-overlay';
  document.body.appendChild(overlay);

  // 2. Initial Page Enter Animation
  document.body.classList.add('page-enter');
  requestAnimationFrame(() => {
    setTimeout(() => {
      document.body.classList.remove('page-enter');
    }, 50);
  });

  // 3. Intercept internal links for Page Exit Animation
  document.addEventListener('click', (e) => {
    const link = e.target.closest('a');
    if (!link) return;
    
    const href = link.getAttribute('href');
    if (!href) return;

    // Only intercept internal html/hash links, ignore external/auth/new tab
    if (
      link.target === '_blank' || 
      href.startsWith('http') || 
      href.startsWith('mailto:') ||
      href.startsWith('/auth')
    ) return;

    // Ignore if it's just an anchor link on the same page
    if (href.startsWith('#') && window.location.pathname === '/' || window.location.pathname === '/index.html') {
       // if it's hash link on index page, just scroll smoothly
       return; 
    }

    // Trigger transition!
    e.preventDefault();
    document.body.classList.add('page-exit');
    
    // Wait for CSS transition (0.6s) before actually navigating
    setTimeout(() => {
      window.location.href = href;
    }, 600);
  });
});
