/**
 * AnimaForge — DDoS & Abuse Detection Middleware
 * Tracks per-IP request rates and auto-bans offenders
 */
'use strict';

// In-memory stores (swap for Redis in production)
const requestCounts = new Map(); // IP → { count, windowStart }
const bannedIPs     = new Map(); // IP → banExpiry timestamp
const suspiciousIPs = new Map(); // IP → strike count

const WINDOWS = {
  SHORT: 60 * 1000,       // 1 minute
  MEDIUM: 5 * 60 * 1000,  // 5 minutes
  LONG: 10 * 60 * 1000,   // 10 minutes
};

const LIMITS = {
  SHORT:  parseInt(process.env.BAN_THRESHOLD_1MIN  || '60'),
  MEDIUM: parseInt(process.env.BAN_THRESHOLD_5MIN  || '200'),
};

const BAN_DURATION = {
  SHORT:  1  * 60 * 60 * 1000,  // 1 hour
  MEDIUM: 6  * 60 * 60 * 1000,  // 6 hours
  LONG:   24 * 60 * 60 * 1000,  // 24 hours
};

// Suspicious user-agent patterns (bots, scrapers, exploit scanners)
const SUSPICIOUS_UA = [
  /sqlmap/i, /nikto/i, /nmap/i, /masscan/i,
  /zgrab/i, /dirbuster/i, /gobuster/i, /hydra/i,
  /burpsuite/i, /acunetix/i, /nessus/i, /openvas/i,
  /havij/i, /webshag/i, /whatweb/i, /wfuzz/i,
  /curl\/7\.[0-4]/i,  // very old curl versions often used in scripts
  /python-requests\/2\.[0-1]/i,
  /go-http-client\/1\.1$/i,
  /libwww-perl/i, /lwp-trivial/i,
  /java\/1\.[0-7]/i,
];

// Paths that are honeypots — no legit user should ever hit these
const HONEYPOT_PATHS = [
  '/wp-admin', '/wp-login.php', '/phpmyadmin',
  '/admin/config.php', '/.env', '/config.php',
  '/shell.php', '/cmd.php', '/eval.php',
  '/.git/config', '/server-status', '/server-info',
  '/actuator', '/actuator/env', '/actuator/beans',
  '/../etc/passwd', '/etc/shadow',
];

function getClientIP(req) {
  return (
    req.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
    req.headers['x-real-ip'] ||
    req.connection?.remoteAddress ||
    req.ip ||
    '0.0.0.0'
  );
}

function banIP(ip, duration, reason) {
  const expiry = Date.now() + duration;
  bannedIPs.set(ip, { expiry, reason });
  console.warn(`[SECURITY] AUTO-BAN: IP ${ip} banned until ${new Date(expiry).toISOString()} | Reason: ${reason}`);
}

function addStrike(ip) {
  const strikes = (suspiciousIPs.get(ip) || 0) + 1;
  suspiciousIPs.set(ip, strikes);
  if (strikes >= 3) {
    banIP(ip, BAN_DURATION.MEDIUM, `${strikes} strikes accumulated`);
    return true;
  }
  return false;
}

// Clean up expired bans and counts periodically
setInterval(() => {
  const now = Date.now();
  for (const [ip, data] of bannedIPs) {
    if (now > data.expiry) bannedIPs.delete(ip);
  }
  for (const [ip, data] of requestCounts) {
    if (now > data.windowStart + WINDOWS.LONG) requestCounts.delete(ip);
  }
}, 5 * 60 * 1000); // clean every 5 min

// ── Main DDoS Middleware ──────────────────────────────────
function ddosProtection(req, res, next) {
  const ip  = getClientIP(req);
  const now = Date.now();
  const ua  = req.headers['user-agent'] || '';
  const path = req.path.toLowerCase();

  // 1. Check if IP is banned
  if (bannedIPs.has(ip)) {
    const ban = bannedIPs.get(ip);
    if (now < ban.expiry) {
      const minutesLeft = Math.ceil((ban.expiry - now) / 60000);
      return res.status(429).json({
        error: 'Access temporarily suspended',
        reason: 'Suspicious activity detected',
        retryAfter: `${minutesLeft} minutes`,
      });
    } else {
      bannedIPs.delete(ip); // expired ban
    }
  }

  // 2. Honeypot path detection
  const isHoneypot = HONEYPOT_PATHS.some(p => path.startsWith(p.toLowerCase()));
  if (isHoneypot) {
    addStrike(ip);
    console.warn(`[SECURITY] HONEYPOT hit by ${ip}: ${req.path}`);
    return res.status(404).json({ error: 'Not found' });
  }

  // 3. Suspicious user-agent detection
  const isSuspiciousUA = SUSPICIOUS_UA.some(r => r.test(ua));
  if (isSuspiciousUA) {
    addStrike(ip);
    console.warn(`[SECURITY] Suspicious UA from ${ip}: ${ua}`);
    return res.status(403).json({ error: 'Forbidden' });
  }

  // 4. Missing User-Agent (raw bots)
  if (!ua || ua.trim().length < 5) {
    addStrike(ip);
    return res.status(403).json({ error: 'Forbidden' });
  }

  // 5. Request rate tracking
  let data = requestCounts.get(ip);
  if (!data || now > data.shortStart + WINDOWS.SHORT) {
    data = { shortCount: 0, shortStart: now, medCount: 0, medStart: now };
  }
  data.shortCount++;
  data.medCount++;

  // Reset medium window if needed
  if (now > data.medStart + WINDOWS.MEDIUM) {
    data.medCount  = 1;
    data.medStart  = now;
  }

  requestCounts.set(ip, data);

  // 6. Short window check (60 req/min)
  if (data.shortCount > LIMITS.SHORT) {
    banIP(ip, BAN_DURATION.SHORT, `Exceeded ${LIMITS.SHORT} req/min`);
    return res.status(429).json({ error: 'Rate limit exceeded', retryAfter: '60 minutes' });
  }

  // 7. Medium window check (200 req/5min)
  if (data.medCount > LIMITS.MEDIUM) {
    banIP(ip, BAN_DURATION.MEDIUM, `Exceeded ${LIMITS.MEDIUM} req/5min`);
    return res.status(429).json({ error: 'Rate limit exceeded', retryAfter: '6 hours' });
  }

  // 8. Add security trace header (internal only, stripped before response)
  req._clientIP = ip;

  next();
}

// ── Path Traversal / Injection Detector ──────────────────
function injectionDetector(req, res, next) {
  const ip = getClientIP(req);
  const fullUrl = req.originalUrl;

  const INJECTION_PATTERNS = [
    /<script[\s\S]*?>/i,
    /javascript:/i,
    /on\w+\s*=/i,
    /union\s+select/i,
    /drop\s+table/i,
    /insert\s+into/i,
    /\.\.\//,
    /%2e%2e/i,
    /\x00/, // null bytes
    /eval\s*\(/i,
    /exec\s*\(/i,
    /base64_decode/i,
  ];

  const toCheck = [
    fullUrl,
    JSON.stringify(req.body || {}),
    JSON.stringify(req.query || {}),
    JSON.stringify(req.params || {}),
  ].join('|');

  const detected = INJECTION_PATTERNS.find(p => p.test(toCheck));
  if (detected) {
    addStrike(ip);
    console.warn(`[SECURITY] Injection attempt from ${ip}: ${fullUrl}`);
    return res.status(400).json({ error: 'Invalid request' });
  }

  next();
}

// ── Admin: Get ban list (internal endpoint) ───────────────
function getBanStatus() {
  return {
    banned: bannedIPs.size,
    suspicious: suspiciousIPs.size,
    tracked: requestCounts.size,
    banList: Array.from(bannedIPs.entries()).map(([ip, data]) => ({
      ip,
      reason: data.reason,
      expiresAt: new Date(data.expiry).toISOString(),
    })),
  };
}

module.exports = { ddosProtection, injectionDetector, getBanStatus, banIP };
