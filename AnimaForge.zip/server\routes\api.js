/**
 * AnimaForge — Animations API Routes
 * GET /api/animations        — list (paginated, filtered, infinite)
 * GET /api/animations/:id    — single animation detail
 * GET /api/categories        — category list with counts
 * GET /api/animations/search — search by name/tag
 */
'use strict';

const express = require('express');
const router  = express.Router();
const xss     = require('xss');
const { animations, categories } = require('../data/animations');
const { apiLimiter } = require('../middleware/security');
const { getPreviewHtml } = require('./generator');

// Apply API rate limiter to all routes
router.use(apiLimiter);

// ── Helper: sanitize string input ────────────────────────
function sanitize(str) {
  if (!str) return '';
  return xss(String(str).trim().slice(0, 200));
}

// ── GET /api/animations ───────────────────────────────────
router.get('/', (req, res) => {
  try {
    let results = [...animations];

    // Filter by category
    const cat = sanitize(req.query.category);
    if (cat && cat !== 'all') {
      results = results.filter(a => a.category === cat);
    }

    // Filter by difficulty
    const diff = sanitize(req.query.difficulty);
    if (diff) {
      results = results.filter(a => a.difficulty === diff);
    }

    // Search by name or format
    const q = sanitize(req.query.q);
    if (q) {
      const lq = q.toLowerCase();
      results = results.filter(a =>
        a.name.toLowerCase().includes(lq) ||
        a.desc.toLowerCase().includes(lq) ||
        a.formats.some(f => f.toLowerCase().includes(lq)) ||
        a.category.toLowerCase().includes(lq)
      );
    }

    // Sort
    const sort = sanitize(req.query.sort);
    if (sort === 'name')      results.sort((a, b) => a.name.localeCompare(b.name));
    if (sort === 'difficulty') {
      const order = { beginner:0, intermediate:1, advanced:2, expert:3 };
      results.sort((a, b) => (order[a.difficulty]||0) - (order[b.difficulty]||0));
    }

    // Pagination & Infinite Generation
    const page    = Math.max(1, parseInt(req.query.page) || 1);
    const limit   = Math.min(50, Math.max(1, parseInt(req.query.limit) || 24));
    const start   = (page - 1) * limit;

    let paged = results.slice(start, start + limit);

    // INFINITE GENERATION: If we run out of base results, generate new ones on the fly
    if (paged.length < limit) {
      const needed = limit - paged.length;
      const startIndex = Math.max(0, start + paged.length - results.length);

      for (let i = 0; i < needed; i++) {
        const genId = startIndex + i + 1;
        const baseAnim = animations[(genId) % animations.length] || animations[0];

        paged.push({
          id: `gen-${cat||'all'}-${genId}`,
          category: baseAnim.category,
          name: `Generated Anim ${genId}`,
          desc: `Procedurally generated limitless animation variant combining ${baseAnim.formats.join(' and ')}.`,
          tier: 'free',
          formats: baseAnim.formats,
          difficulty: ['beginner', 'intermediate', 'advanced', 'expert'][genId % 4],
          locked: false,
          preview: baseAnim.preview
        });
      }
    }

    // Force all results to be unlocked and inject previewHtml
    const sanitizedResults = paged.map(a => ({
      ...a,
      tier: 'free',
      locked: false,
      previewHtml: getPreviewHtml(a.preview || '')
    }));

    res.json({
      success: true,
      data: sanitizedResults,
      meta: {
        total: 9999999,
        page,
        limit,
        totalPages: 999999,
        isPremium: true,
      },
    });
  } catch (err) {
    console.error('[API] /animations error:', err.message);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ── GET /api/animations/search ────────────────────────────
router.get('/search', (req, res) => {
  try {
    const q = sanitize(req.query.q);
    if (!q || q.length < 2) {
      return res.json({ success: true, data: [], meta: { total: 0 } });
    }

    const lq = q.toLowerCase();
    const results = animations
      .filter(a =>
        a.name.toLowerCase().includes(lq) ||
        a.desc.toLowerCase().includes(lq) ||
        a.category.toLowerCase().includes(lq) ||
        a.formats.some(f => f.toLowerCase().includes(lq))
      )
      .slice(0, 20)
      .map(a => ({
        ...a,
        locked: false,
        tier: 'free'
      }));

    res.json({ success: true, data: results, meta: { total: results.length, query: q } });
  } catch (err) {
    res.status(500).json({ error: 'Search failed' });
  }
});

// ── GET /api/animations/:id ───────────────────────────────
router.get('/:id', (req, res) => {
  try {
    const id = sanitize(req.params.id);

    if (id.startsWith('gen-')) {
      return res.json({
        success: true,
        data: {
          id,
          name: 'Generated Animation',
          desc: 'Procedurally generated animation details.',
          tier: 'free',
          category: 'canvas-2d',
          formats: ['JS', 'Canvas'],
          difficulty: 'advanced',
          locked: false,
          preview: 'particle-bg',
          previewHtml: getPreviewHtml('particle-bg')
        }
      });
    }

    const anim = animations.find(a => a.id === id);
    if (!anim) return res.status(404).json({ error: 'Animation not found' });

    res.json({
      success: true,
      data: {
        ...anim,
        locked: false,
        tier: 'free',
        previewHtml: getPreviewHtml(anim.preview || '')
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ── GET /api/categories ───────────────────────────────────
router.get('/meta/categories', (req, res) => {
  res.json({ success: true, data: categories });
});

// ── GET /api/stats — Public stats ────────────────────────
router.get('/meta/stats', (req, res) => {
  const total = 9999999;
  const free = 9999999;
  const premium = 0;
  const cats = [...new Set(animations.map(a => a.category))].length;

  res.json({
    success: true,
    data: { total, free, premium, categories: cats },
  });
});

module.exports = router;
