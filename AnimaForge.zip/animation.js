/**
 * ANIMAFORGE v2.0 — animation.js
 * Single animation detail page logic
 */

'use strict';

document.addEventListener('DOMContentLoaded', () => {
  const urlParams = new URLSearchParams(window.location.search);
  const animId = urlParams.get('id');

  const previewStage = document.getElementById('previewStage');
  const animTitle = document.getElementById('animTitle');
  const animDesc = document.getElementById('animDesc');
  const animMeta = document.getElementById('animMeta');
  
  const tabHtmlBtn = document.getElementById('tabBtn-html');
  const tabCssBtn = document.getElementById('tabBtn-css');
  const tabJsBtn = document.getElementById('tabBtn-js');
  const codeHtml = document.getElementById('code-html');
  const codeCss = document.getElementById('code-css');
  const codeJs = document.getElementById('code-js');

  const copyCodeBtn = document.getElementById('copyCodeBtn');

  let currentAnim = null;

  if (!animId) {
    if (animTitle) animTitle.innerText = 'Animation Not Found';
    return;
  }

  async function fetchAnimationDetail() {
    try {
      const res = await fetch(`/api/animations/${animId}`);
      if (res.ok) {
        const data = await res.json();
        currentAnim = data.data;
        renderDetail();
      } else {
        if (animTitle) animTitle.innerText = 'Animation Not Found';
      }
    } catch (err) {
      console.error(err);
      if (animTitle) animTitle.innerText = 'Error loading animation';
    }
  }

  function renderDetail() {
    if (!currentAnim) return;

    // Header
    if (animTitle) animTitle.innerText = currentAnim.name;
    if (animDesc) animDesc.innerText = currentAnim.desc;
    
    // Meta tags
    if (animMeta) {
      animMeta.innerHTML = `
        <span class="diff-badge diff-${currentAnim.difficulty}">${currentAnim.difficulty.toUpperCase()}</span>
        ${currentAnim.formats.map(f => `<span class="format-tag">${f}</span>`).join('')}
      `;
    }

    // Code & Preview
    const previewHtml = currentAnim.previewHtml;
    if (previewHtml) {
      // 1. Extract raw code from the full document
      const rawHtml = extractBodyContent(previewHtml);
      const rawCss = extractStyleContent(previewHtml);
      const rawJs = extractScriptContent(previewHtml);
      
      // Setup the code tabs
      if (codeHtml) codeHtml.textContent = `<!-- ${currentAnim.name} -->\n<!-- You can also right-click the preview > Inspect to view source -->\n\n${rawHtml}`;
      if (codeCss) codeCss.textContent = rawCss;
      if (codeJs) codeJs.textContent = rawJs;
      
      // Provide fallback context to currentAnim.code for the copy button
      currentAnim.code = { html: codeHtml.textContent, css: rawCss, js: rawJs };

      // 2. Inject live preview into the stage via iframe srcdoc
      if (previewStage) {
        previewStage.innerHTML = '';
        const iframe = document.createElement('iframe');
        iframe.style.cssText = 'width:100%;height:100%;border:none;display:block;';
        iframe.setAttribute('sandbox', 'allow-scripts');
        iframe.srcdoc = previewHtml;
        previewStage.appendChild(iframe);
      }
    }
  }

  // ── Code extraction helpers ───────────────────────────────
  function extractBodyContent(html) {
    const match = html.match(/<body[^>]*>([\s\S]*?)<script/i);
    return match ? match[1].trim() : html;
  }

  function extractStyleContent(html) {
    const match = html.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
    return match ? match[1].trim() : '/* No CSS */';
  }

  function extractScriptContent(html) {
    const match = html.match(/<script[^>]*>\s*\(function\(\) \{\s*try \{([\s\S]*?)\} catch/i);
    return match ? match[1].trim() : '// No JS';
  }

  // Tabs
  function setupTabs() {
    const tabs = [
      { btn: tabHtmlBtn, panel: codeHtml },
      { btn: tabCssBtn, panel: codeCss },
      { btn: tabJsBtn, panel: codeJs },
    ];

    tabs.forEach(t => {
      if (t.btn) {
        t.btn.addEventListener('click', () => {
          tabs.forEach(x => {
            x.btn.classList.remove('active');
            x.panel.parentElement.style.display = 'none';
          });
          t.btn.classList.add('active');
          t.panel.parentElement.style.display = 'block';
        });
      }
    });

    // Default to HTML active
    if (tabHtmlBtn) tabHtmlBtn.click();
  }

  if (copyCodeBtn) {
    copyCodeBtn.addEventListener('click', () => {
      if (!currentAnim || !currentAnim.code) return;
      const activeTabBtn = document.querySelector('.code-tab.active');
      const activeType = activeTabBtn ? activeTabBtn.dataset.type : 'html';
      const textToCopy = currentAnim.code[activeType];
      
      if (textToCopy) {
        window.copyToClipboard(textToCopy, `${activeType.toUpperCase()} Code Copied!`);
      }
    });
  }

  setupTabs();
  fetchAnimationDetail();

});
