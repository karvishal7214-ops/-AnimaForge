/**
 * ANIMAFORGE v3.0 — library.js
 * Library page: Renders each animation in its own <iframe srcdoc> for perfect isolation.
 */

'use strict';

document.addEventListener('DOMContentLoaded', () => {
  const state = {
    animations: [],
    categories: [],
    filters: { category: 'all', difficulty: '', search: '', sort: '' },
    pagination: { page: 1, limit: 24, total: 0, totalPages: 0 },
    isLoading: true
  };

  const API_BASE = '/api';
  const animGrid             = document.getElementById('animGrid');
  const catPillsContainer    = document.getElementById('catPills');
  const searchInput          = document.getElementById('searchInput');
  const searchClear          = document.getElementById('searchClear');
  const filterChips          = document.querySelectorAll('.chip');
  const sortSelect           = document.getElementById('sortSelect');
  const paginationContainer  = document.getElementById('pagination');

  // ── Fetch categories ─────────────────────────────────────
  async function fetchCategories() {
    try {
      const res = await fetch(`${API_BASE}/animations/meta/categories`);
      if (res.ok) {
        const data = await res.json();
        state.categories = data.data;
        renderCategoryPills();
      }
    } catch (err) {
      console.error('Failed to load categories', err);
    }
  }

  // ── Fetch animations ─────────────────────────────────────
  async function fetchAnimations() {
    state.isLoading = true;
    renderSkeletons();

    const params = new URLSearchParams({ page: state.pagination.page, limit: state.pagination.limit });
    if (state.filters.category && state.filters.category !== 'all') params.append('category', state.filters.category);
    if (state.filters.difficulty) params.append('difficulty', state.filters.difficulty);
    if (state.filters.search)    params.append('q', state.filters.search);
    if (state.filters.sort)      params.append('sort', state.filters.sort);

    try {
      const res = await fetch(`${API_BASE}/animations?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        state.animations = data.data;
        state.pagination = { ...state.pagination, ...data.meta };
        renderAnimations();
        renderPagination();
      }
    } catch (err) {
      console.error('Failed to load animations', err);
      if (animGrid) animGrid.innerHTML = '<p style="text-align:center;color:var(--text-muted);grid-column:1/-1;">Error loading animations. Please try again.</p>';
    } finally {
      state.isLoading = false;
    }
  }

  // ── Skeletons ─────────────────────────────────────────────
  function renderSkeletons() {
    if (!animGrid) return;
    animGrid.innerHTML = Array(6).fill('<div class="anim-card-skeleton" aria-hidden="true"></div>').join('');
  }

  // ── Category pills ────────────────────────────────────────
  function renderCategoryPills() {
    if (!catPillsContainer) return;
    let html = `<button class="cat-pill ${state.filters.category === 'all' ? 'active' : ''}" data-cat="all">All</button>`;
    state.categories.forEach(cat => {
      const isActive = state.filters.category === cat.id ? 'active' : '';
      html += `<button class="cat-pill ${isActive}" data-cat="${cat.id}">${cat.label} (${cat.count})</button>`;
    });
    catPillsContainer.innerHTML = html;
    catPillsContainer.querySelectorAll('.cat-pill').forEach(pill => {
      pill.addEventListener('click', () => {
        state.filters.category = pill.dataset.cat;
        state.pagination.page = 1;
        fetchAnimations();
        renderCategoryPills();
      });
    });
  }

  // ── Render animations using <iframe srcdoc> ───────────────
  function renderAnimations() {
    if (!animGrid) return;

    if (state.animations.length === 0) {
      animGrid.innerHTML = '<p style="text-align:center;color:var(--text-muted);grid-column:1/-1;padding:40px;">No animations found matching your criteria.</p>';
      return;
    }

    animGrid.innerHTML = '';

    state.animations.forEach(anim => {
      const diffClass  = `diff-${anim.difficulty}`;
      const formatTags = anim.formats.map(f =>
        `<span style="background:rgba(255,255,255,.05);padding:2px 6px;border-radius:4px;font-size:10px;">${f}</span>`
      ).join('');

      // Create card element
      const card = document.createElement('div');
      card.className = 'demo-card';
      card.dataset.id = anim.id;

      // Preview stage: an iframe with srcdoc
      const stage = document.createElement('div');
      stage.className = 'demo-stage';
      stage.style.cssText = 'height:200px;padding:0;position:relative;overflow:hidden;';

      const iframe = document.createElement('iframe');
      iframe.style.cssText = 'width:100%;height:100%;border:none;display:block;';
      iframe.setAttribute('sandbox', 'allow-scripts');
      iframe.setAttribute('loading', 'lazy');

      // Set srcdoc — all animation code isolated in its own document
      if (anim.previewHtml) {
        iframe.srcdoc = anim.previewHtml;
      }

      stage.appendChild(iframe);

      // Info section
      const info = document.createElement('div');
      info.className = 'demo-info';
      info.style.cssText = 'color:inherit;display:block;cursor:pointer;';
      info.innerHTML = `
        <h3 style="font-size:16px;margin:0 0 4px 0;">${anim.name}</h3>
        <p style="font-size:13px;color:var(--text-muted);margin:0 0 12px 0;">${anim.desc.slice(0, 60)}...</p>
        <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
          <span class="diff-badge ${diffClass}" style="font-size:10px;">${anim.difficulty.toUpperCase()}</span>
          ${formatTags}
        </div>`;

      // Clicking card (stage or info) opens the preview+code modal
      card.style.cursor = 'pointer';
      card.addEventListener('click', () => openAnimPreviewModal(anim));

      card.appendChild(stage);
      card.appendChild(info);
      animGrid.appendChild(card);
    });
  }

  // ── Full-screen Preview + Code Modal ─────────────────────
  async function openAnimPreviewModal(anim) {
    // Remove any existing modal
    const old = document.getElementById('animPreviewModal');
    if (old) old.remove();

    // Show a loading state first
    const modal = document.createElement('div');
    modal.id = 'animPreviewModal';
    modal.style.cssText = `
      position:fixed;inset:0;z-index:9999;
      background:rgba(0,0,0,.88);backdrop-filter:blur(16px);
      display:flex;align-items:center;justify-content:center;
      padding:20px;box-sizing:border-box;`;

    const inner = document.createElement('div');
    inner.style.cssText = `
      width:100%;max-width:1100px;height:85vh;
      border-radius:24px;overflow:hidden;
      border:1px solid rgba(168,85,247,.3);
      background:#0d0d14;
      display:flex;flex-direction:column;
      box-shadow:0 0 100px rgba(168,85,247,.25);`;

    // ── Header ──────────────────────────────────────────
    const header = document.createElement('div');
    header.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:16px 24px;border-bottom:1px solid rgba(255,255,255,.07);flex-shrink:0;gap:12px;';
    header.innerHTML = `
      <div style="min-width:0;">
        <h2 style="font-size:17px;font-weight:800;margin:0 0 2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${anim.name}</h2>
        <p style="font-size:12px;color:#777;margin:0;">${anim.desc}</p>
      </div>
      <div style="display:flex;gap:8px;align-items:center;flex-shrink:0;">
        <button id="copyAllBtn" style="padding:8px 16px;border-radius:10px;background:linear-gradient(135deg,#a855f7,#6366f1);color:#fff;font-size:13px;font-weight:700;border:none;cursor:pointer;">⧉ Copy Code</button>
        <button id="closeAnimModal" style="width:34px;height:34px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.05);color:#aaa;font-size:18px;cursor:pointer;">✕</button>
      </div>`;

    // ── Body: split layout ───────────────────────────────
    const body = document.createElement('div');
    body.style.cssText = 'display:flex;flex:1;overflow:hidden;min-height:0;';

    // Left: live preview
    const previewPane = document.createElement('div');
    previewPane.style.cssText = `
      flex:1;display:flex;flex-direction:column;border-right:1px solid rgba(255,255,255,.07);
      background-image:radial-gradient(rgba(255,255,255,.04) 1px,transparent 1px);
      background-size:22px 22px;background-color:#080810;min-width:0;`;

    const previewLabel = document.createElement('div');
    previewLabel.style.cssText = 'padding:10px 16px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#555;border-bottom:1px solid rgba(255,255,255,.05);flex-shrink:0;';
    previewLabel.textContent = '▶  Live Preview';

    const previewIframeWrap = document.createElement('div');
    previewIframeWrap.style.cssText = 'flex:1;position:relative;';

    const previewIframe = document.createElement('iframe');
    previewIframe.style.cssText = 'width:100%;height:100%;border:none;display:block;';
    previewIframe.setAttribute('sandbox', 'allow-scripts');
    if (anim.previewHtml) previewIframe.srcdoc = anim.previewHtml;

    previewIframeWrap.appendChild(previewIframe);
    previewPane.appendChild(previewLabel);
    previewPane.appendChild(previewIframeWrap);

    // Right: code panel
    const codePane = document.createElement('div');
    codePane.style.cssText = 'width:420px;flex-shrink:0;display:flex;flex-direction:column;min-width:0;';

    const codePaneLabel = document.createElement('div');
    codePaneLabel.style.cssText = 'padding:10px 16px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#555;border-bottom:1px solid rgba(255,255,255,.05);flex-shrink:0;display:flex;gap:0;';

    const tabs = [
      { key: 'html', label: 'HTML', color: '#f472b6' },
      { key: 'css',  label: 'CSS',  color: '#c084fc' },
      { key: 'js',   label: 'JS',   color: '#fbbf24' },
    ];

    let activeTab = 'html';
    const codeData = { html: '// Loading...', css: '/* Loading... */', js: '// Loading...' };

    tabs.forEach(t => {
      const btn = document.createElement('button');
      btn.dataset.tab = t.key;
      btn.style.cssText = `padding:10px 18px;border:none;background:transparent;font-size:12px;font-weight:700;color:${t.color};cursor:pointer;border-bottom:2px solid ${t.key === activeTab ? t.color : 'transparent'};transition:all .2s;opacity:${t.key === activeTab ? 1 : .45};`;
      btn.textContent = t.label;
      btn.addEventListener('click', () => {
        activeTab = t.key;
        updateCodeView();
        codePaneLabel.querySelectorAll('button').forEach((b, i) => {
          b.style.borderBottomColor = b.dataset.tab === t.key ? tabs[i].color : 'transparent';
          b.style.opacity = b.dataset.tab === t.key ? '1' : '.45';
        });
      });
      codePaneLabel.appendChild(btn);
    });

    const codeDisplay = document.createElement('pre');
    codeDisplay.style.cssText = `flex:1;overflow:auto;margin:0;padding:20px;font-family:"JetBrains Mono",monospace;font-size:12.5px;line-height:1.75;color:#e2e8f0;background:transparent;`;

    const codeEl = document.createElement('code');
    codeDisplay.appendChild(codeEl);

    function updateCodeView() {
      codeEl.textContent = codeData[activeTab] || `// No ${activeTab.toUpperCase()} for this animation`;
    }

    codePane.appendChild(codePaneLabel);
    codePane.appendChild(codeDisplay);

    body.appendChild(previewPane);
    body.appendChild(codePane);

    inner.appendChild(header);
    inner.appendChild(body);
    modal.appendChild(inner);
    document.body.appendChild(modal);

    // ── Wire up buttons ──────────────────────────────────
    header.querySelector('#closeAnimModal').addEventListener('click', () => modal.remove());
    modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });

    const copyAllBtn = header.querySelector('#copyAllBtn');
    copyAllBtn.addEventListener('click', () => {
      const text = codeData[activeTab];
      if (text) {
        navigator.clipboard.writeText(text).then(() => {
          copyAllBtn.textContent = '✓ Copied!';
          copyAllBtn.style.background = 'linear-gradient(135deg,#10b981,#06b6d4)';
          setTimeout(() => {
            copyAllBtn.textContent = '⧉ Copy Code';
            copyAllBtn.style.background = 'linear-gradient(135deg,#a855f7,#6366f1)';
          }, 2000);
        });
      }
    });

    const escHandler = (e) => { if (e.key === 'Escape') { modal.remove(); document.removeEventListener('keydown', escHandler); } };
    document.addEventListener('keydown', escHandler);

    // ── Fetch full code from API ─────────────────────────
    try {
      const res = await fetch(`/api/animations/${anim.id}`);
      if (res.ok) {
        const data = await res.json();
        const fullAnim = data.data;
        // The detail API now returns previewHtml; reconstruct readable code from generator approach
        // Build human-readable placeholder code blocks for copying
        const fmts = fullAnim.formats || [];
        const isCss = fmts.includes('CSS') || fmts.includes('HTML');
        
        codeData.html = `<!-- ${fullAnim.name} -->\n<!-- Copy from the Live Preview (Ctrl+U to view source) -->\n\n${anim.previewHtml ? extractBodyContent(anim.previewHtml) : `<div class="${anim.id}">\n  <!-- ${fullAnim.name} animation element -->\n</div>`}`;
        codeData.css = extractStyleContent(anim.previewHtml || '');
        codeData.js = extractScriptContent(anim.previewHtml || '');

        updateCodeView();
      }
    } catch(err) {
      codeEl.textContent = '// Could not load code. Please try again.';
    }

    updateCodeView();
  }

  // ── Code extraction helpers ───────────────────────────────
  function extractBodyContent(html) {
    const match = html.match(/<body[^>]*>([\s\S]*?)<script/i);
    return match ? match[1].trim() : html;
  }

  function extractStyleContent(html) {
    const match = html.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
    return match ? match[1].trim() : '/* No CSS */';
  }

  function extractScriptContent(html) {
    const match = html.match(/<script[^>]*>\s*\(function\(\) \{\s*try \{([\s\S]*?)\} catch/i);
    return match ? match[1].trim() : '// No JS';
  }

  // ── Pagination ────────────────────────────────────────────
  function renderPagination() {
    if (!paginationContainer) return;
    const { page } = state.pagination;

    let html = '';
    if (page > 1) html += `<button class="page-btn" data-page="${page - 1}">Prev</button>`;
    for (let i = Math.max(1, page - 2); i <= page + 2; i++) {
      html += `<button class="page-btn ${i === page ? 'active' : ''}" data-page="${i}">${i}</button>`;
    }
    html += `<button class="page-btn" data-page="${page + 1}">Next</button>`;

    paginationContainer.innerHTML = html;
    paginationContainer.querySelectorAll('.page-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        state.pagination.page = parseInt(btn.dataset.page);
        fetchAnimations();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });
  }

  // ── Search ────────────────────────────────────────────────
  if (searchInput) {
    let timeout;
    searchInput.addEventListener('input', (e) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        state.filters.search = e.target.value;
        state.pagination.page = 1;
        fetchAnimations();
      }, 400);
    });
  }

  if (searchClear) {
    searchClear.addEventListener('click', () => {
      if (searchInput) searchInput.value = '';
      state.filters.search = '';
      state.pagination.page = 1;
      fetchAnimations();
    });
  }

  // ── Sort ──────────────────────────────────────────────────
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      state.filters.sort = e.target.value;
      state.pagination.page = 1;
      fetchAnimations();
    });
  }

  // ── Difficulty chips ──────────────────────────────────────
  filterChips.forEach(chip => {
    chip.addEventListener('click', () => {
      if (['beginner', 'intermediate', 'advanced'].includes(chip.dataset.filter)) {
        if (chip.classList.contains('active')) {
          chip.classList.remove('active');
          state.filters.difficulty = '';
        } else {
          filterChips.forEach(c => {
            if (['beginner', 'intermediate', 'advanced'].includes(c.dataset.filter)) c.classList.remove('active');
          });
          chip.classList.add('active');
          state.filters.difficulty = chip.dataset.filter;
        }
      } else if (chip.dataset.filter === 'all') {
        filterChips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        state.filters.difficulty = '';
      }
      state.pagination.page = 1;
      fetchAnimations();
    });
  });

  // ── URL params for category linking ───────────────────────
  const urlParams = new URLSearchParams(window.location.search);
  const startCat = urlParams.get('category');
  if (startCat) state.filters.category = startCat;

  // ── Bootstrap ─────────────────────────────────────────────
  fetchCategories();
  fetchAnimations();
});
