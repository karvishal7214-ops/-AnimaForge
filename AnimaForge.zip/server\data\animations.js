/**
 * AnimaForge — Animation Library Data (200+ entries)
 * tier: 'free' | 'premium'
 * format: array of format tags
 */
'use strict';

const animations = [

  // ═══════════════════════════════════════════════
  // CATEGORY 1: MOTION & PHYSICS
  // ═══════════════════════════════════════════════
  { id:'mp-001', category:'motion-physics', name:'Magnetic Button', desc:'Cursor-attracted button with spring physics', tier:'free', formats:['JS','CSS','Mouse Events'], difficulty:'intermediate', preview:'magnetic' },
  { id:'mp-002', category:'motion-physics', name:'Spring Bounce', desc:'Over-damped spring animation on click', tier:'free', formats:['JS','CSS'], difficulty:'beginner', preview:'spring' },
  { id:'mp-003', category:'motion-physics', name:'Inertia Drag', desc:'Mouse-drag with momentum and deceleration', tier:'premium', formats:['Canvas','JS'], difficulty:'advanced', preview:'inertia' },
  { id:'mp-004', category:'motion-physics', name:'Gravity Fall', desc:'Elements fall with realistic gravity curve', tier:'premium', formats:['JS','CSS','Keyframes'], difficulty:'advanced', preview:'gravity' },
  { id:'mp-005', category:'motion-physics', name:'Elastic Snap', desc:'Rubber-band elastic pull and snap-back', tier:'free', formats:['CSS','Custom Props'], difficulty:'intermediate', preview:'elastic' },

  // ═══════════════════════════════════════════════
  // CATEGORY 2: TEXT EFFECTS
  // ═══════════════════════════════════════════════
  { id:'te-001', category:'text-effects', name:'Glitch Effect', desc:'Cyberpunk RGB split glitch animation', tier:'free', formats:['CSS','Pseudo-elements'], difficulty:'beginner', preview:'glitch' },
  { id:'te-002', category:'text-effects', name:'Typewriter', desc:'Multi-phrase looping typewriter with erase', tier:'free', formats:['JS','Interval'], difficulty:'beginner', preview:'typewriter' },
  { id:'te-003', category:'text-effects', name:'Text Split Reveal', desc:'Word-by-word staggered reveal on scroll', tier:'free', formats:['JS','CSS','IntersectionObserver'], difficulty:'intermediate', preview:'split' },
  { id:'te-004', category:'text-effects', name:'Scramble Text', desc:'Matrix-style character scramble hover effect', tier:'premium', formats:['JS','RAF'], difficulty:'advanced', preview:'scramble' },
  { id:'te-005', category:'text-effects', name:'Gradient Wave Text', desc:'Animated hue-shifting gradient on text', tier:'free', formats:['CSS','@keyframes'], difficulty:'beginner', preview:'gradient-text' },
  { id:'te-006', category:'text-effects', name:'Kinetic 3D Text', desc:'Perspective-rotated 3D text on mouse move', tier:'premium', formats:['CSS','JS','perspective'], difficulty:'advanced', preview:'kinetic-3d' },
  { id:'te-007', category:'text-effects', name:'Neon Flicker', desc:'Flickering neon sign with layered shadows', tier:'free', formats:['CSS','box-shadow'], difficulty:'beginner', preview:'neon' },
  { id:'te-008', category:'text-effects', name:'Morphing Font Weight', desc:'Variable font weight animation on hover', tier:'premium', formats:['CSS','Variable Fonts'], difficulty:'intermediate', preview:'variable-font' },

  // ═══════════════════════════════════════════════
  // CATEGORY 3: HOVER EFFECTS
  // ═══════════════════════════════════════════════
  { id:'hv-001', category:'hover-effects', name:'3D Tilt Card', desc:'Mouse-tracking perspective tilt with shine', tier:'free', formats:['JS','CSS'], difficulty:'intermediate', preview:'tilt' },
  { id:'hv-002', category:'hover-effects', name:'Shine Sweep', desc:'Diagonal light sweep across element on hover', tier:'free', formats:['CSS','pseudo-elements'], difficulty:'beginner', preview:'shine' },
  { id:'hv-003', category:'hover-effects', name:'Reveal Slide', desc:'Content slides in from bottom on hover', tier:'free', formats:['CSS','overflow'], difficulty:'beginner', preview:'reveal-slide' },
  { id:'hv-004', category:'hover-effects', name:'Liquid Fill', desc:'Liquid fill animation from any direction', tier:'premium', formats:['CSS','clip-path'], difficulty:'intermediate', preview:'liquid-fill' },
  { id:'hv-005', category:'hover-effects', name:'Border Trace', desc:'Animated border that traces around element', tier:'free', formats:['CSS','SVG'], difficulty:'intermediate', preview:'border-trace' },
  { id:'hv-006', category:'hover-effects', name:'Image Zoom Reveal', desc:'Smooth zoom with mask reveal on hover', tier:'premium', formats:['CSS','clip-path'], difficulty:'intermediate', preview:'image-zoom' },

  // ═══════════════════════════════════════════════
  // CATEGORY 4: LOADING STATES
  // ═══════════════════════════════════════════════
  { id:'ls-001', category:'loading', name:'Layered Spinner', desc:'Three-ring counter-rotating loader', tier:'free', formats:['CSS','@keyframes'], difficulty:'beginner', preview:'spinner' },
  { id:'ls-002', category:'loading', name:'Skeleton Shimmer', desc:'Shimmer-wave skeleton placeholder', tier:'free', formats:['CSS','linear-gradient'], difficulty:'beginner', preview:'skeleton' },
  { id:'ls-003', category:'loading', name:'Dot Pulse', desc:'Three dots pulsing in sequence', tier:'free', formats:['CSS','animation-delay'], difficulty:'beginner', preview:'dot-pulse' },
  { id:'ls-004', category:'loading', name:'Progress Bar', desc:'Animated fill-up progress with label', tier:'free', formats:['CSS','JS'], difficulty:'beginner', preview:'progress' },
  { id:'ls-005', category:'loading', name:'Circular Progress', desc:'SVG stroke-dashoffset circular loader', tier:'free', formats:['SVG','CSS'], difficulty:'intermediate', preview:'circular-progress' },
  { id:'ls-006', category:'loading', name:'Morphing Loader', desc:'Shape-morphing SVG loading animation', tier:'premium', formats:['SVG','GSAP-like','JS'], difficulty:'advanced', preview:'morph-loader' },
  { id:'ls-007', category:'loading', name:'Heartbeat Pulse', desc:'ECG-style heartbeat loading line', tier:'premium', formats:['SVG','CSS'], difficulty:'intermediate', preview:'heartbeat' },

  // ═══════════════════════════════════════════════
  // CATEGORY 5: SCROLL ANIMATIONS
  // ═══════════════════════════════════════════════
  { id:'sc-001', category:'scroll', name:'Fade In Up', desc:'Elements fade and rise on scroll', tier:'free', formats:['JS','IntersectionObserver'], difficulty:'beginner', preview:'fade-up' },
  { id:'sc-002', category:'scroll', name:'Parallax Layers', desc:'Multi-layer depth parallax on scroll', tier:'free', formats:['JS','CSS transform'], difficulty:'intermediate', preview:'parallax' },
  { id:'sc-003', category:'scroll', name:'Scroll Counter', desc:'Number count-up triggered by scroll', tier:'free', formats:['JS','IntersectionObserver'], difficulty:'beginner', preview:'counter' },
  { id:'sc-004', category:'scroll', name:'Sticky Header Morph', desc:'Header transforms as user scrolls', tier:'free', formats:['JS','CSS'], difficulty:'intermediate', preview:'sticky-header' },
  { id:'sc-005', category:'scroll', name:'SVG Path Draw', desc:'SVG stroke draws on scroll progress', tier:'premium', formats:['SVG','JS','scroll'], difficulty:'advanced', preview:'path-draw' },
  { id:'sc-006', category:'scroll', name:'Horizontal Scroll Gallery', desc:'Horizontal scroll transformed by vertical wheel', tier:'premium', formats:['JS','CSS','transform'], difficulty:'advanced', preview:'h-scroll' },
  { id:'sc-007', category:'scroll', name:'Pinned Section Transition', desc:'Section pins and morphs before scrolling away', tier:'premium', formats:['JS','CSS','position:sticky'], difficulty:'advanced', preview:'pin-section' },

  // ═══════════════════════════════════════════════
  // CATEGORY 6: BACKGROUND EFFECTS
  // ═══════════════════════════════════════════════
  { id:'bg-001', category:'background', name:'Particle Network', desc:'Connected floating particles on canvas', tier:'free', formats:['Canvas','JS'], difficulty:'intermediate', preview:'particles' },
  { id:'bg-002', category:'background', name:'Aurora Borealis', desc:'Animated northern lights gradient mesh', tier:'premium', formats:['CSS','@keyframes','conic-gradient'], difficulty:'advanced', preview:'aurora' },
  { id:'bg-003', category:'background', name:'Animated Mesh Gradient', desc:'Smooth multi-point colour mesh animation', tier:'free', formats:['CSS','@keyframes'], difficulty:'beginner', preview:'mesh' },
  { id:'bg-004', category:'background', name:'Noise Grain Texture', desc:'Animated noise grain overlay effect', tier:'premium', formats:['Canvas','JS'], difficulty:'intermediate', preview:'noise' },
  { id:'bg-005', category:'background', name:'Bubble Float', desc:'Rising translucent bubbles on canvas', tier:'free', formats:['Canvas','JS'], difficulty:'intermediate', preview:'bubbles' },
  { id:'bg-006', category:'background', name:'Wave Ripple', desc:'Sine-wave ripple background animation', tier:'premium', formats:['Canvas','JS','Math'], difficulty:'advanced', preview:'wave' },
  { id:'bg-007', category:'background', name:'Star Field', desc:'Starfield depth-of-field parallax', tier:'free', formats:['Canvas','JS'], difficulty:'intermediate', preview:'stars' },
  { id:'bg-008', category:'background', name:'Flowing Gradient', desc:'Smooth hue-rotating full-screen gradient', tier:'free', formats:['CSS','@keyframes','filter:hue-rotate'], difficulty:'beginner', preview:'flowing-gradient' },
  { id:'bg-009', category:'background', name:'Matrix Rain', desc:'Classic Matrix digital rain on canvas', tier:'premium', formats:['Canvas','JS'], difficulty:'advanced', preview:'matrix' },
  { id:'bg-010', category:'background', name:'Perlin Noise Blob', desc:'Organic noise-driven shape background', tier:'premium', formats:['Canvas','JS','Perlin'], difficulty:'expert', preview:'perlin' },

  // ═══════════════════════════════════════════════
  // CATEGORY 7: BUTTONS & CTAs
  // ═══════════════════════════════════════════════
  { id:'bt-001', category:'buttons', name:'Ripple Effect', desc:'Material Design click ripple', tier:'free', formats:['CSS','JS'], difficulty:'beginner', preview:'ripple' },
  { id:'bt-002', category:'buttons', name:'Magnetic Pull', desc:'Button attracted to cursor spring physics', tier:'free', formats:['JS','CSS'], difficulty:'intermediate', preview:'magnetic' },
  { id:'bt-003', category:'buttons', name:'Border Gradient Spin', desc:'Rotating conic-gradient border button', tier:'free', formats:['CSS','@property','conic-gradient'], difficulty:'intermediate', preview:'gradient-border' },
  { id:'bt-004', category:'buttons', name:'Fill Slide', desc:'Color fill slides in from left on hover', tier:'free', formats:['CSS'], difficulty:'beginner', preview:'fill-slide' },
  { id:'bt-005', category:'buttons', name:'Particle Burst', desc:'Canvas particle explosion on click', tier:'free', formats:['Canvas','JS'], difficulty:'intermediate', preview:'particle' },
  { id:'bt-006', category:'buttons', name:'Morph Button', desc:'Button morphs into loading spinner', tier:'premium', formats:['CSS','JS','clip-path'], difficulty:'advanced', preview:'morph-btn' },
  { id:'bt-007', category:'buttons', name:'3D Press', desc:'Tactile 3D depth press animation', tier:'free', formats:['CSS','box-shadow'], difficulty:'beginner', preview:'btn-3d' },
  { id:'bt-008', category:'buttons', name:'Glitch Button', desc:'Glitch effect activates on hover', tier:'premium', formats:['CSS','pseudo-elements'], difficulty:'intermediate', preview:'glitch-btn' },

  // ═══════════════════════════════════════════════
  // CATEGORY 8: CARDS
  // ═══════════════════════════════════════════════
  { id:'ca-001', category:'cards', name:'3D Card Flip', desc:'CSS perspective card flip animation', tier:'free', formats:['CSS','perspective'], difficulty:'beginner', preview:'flip' },
  { id:'ca-002', category:'cards', name:'Hover Tilt Glow', desc:'3D tilt with dynamic specular glow', tier:'free', formats:['JS','CSS'], difficulty:'intermediate', preview:'tilt' },
  { id:'ca-003', category:'cards', name:'Stack Hover', desc:'Stacked cards fan out on hover', tier:'premium', formats:['CSS','transform'], difficulty:'intermediate', preview:'card-stack' },
  { id:'ca-004', category:'cards', name:'Content Reveal', desc:'Image scale with content slides up', tier:'free', formats:['CSS','overflow'], difficulty:'beginner', preview:'card-reveal' },
  { id:'ca-005', category:'cards', name:'Glassmorphism Card', desc:'Frosted glass card with blur and borders', tier:'free', formats:['CSS','backdrop-filter'], difficulty:'beginner', preview:'glass' },
  { id:'ca-006', category:'cards', name:'Holographic Card', desc:'Rainbow holographic foil hover effect', tier:'premium', formats:['JS','CSS','conic-gradient'], difficulty:'advanced', preview:'holo' },

  // ═══════════════════════════════════════════════
  // CATEGORY 9: PAGE TRANSITIONS
  // ═══════════════════════════════════════════════
  { id:'pt-001', category:'page-transitions', name:'Fade Cross', desc:'Smooth opacity cross-fade between views', tier:'free', formats:['CSS','JS'], difficulty:'beginner', preview:'fade' },
  { id:'pt-002', category:'page-transitions', name:'Slide Push', desc:'New page slides in, old slides out', tier:'free', formats:['CSS','transform'], difficulty:'intermediate', preview:'slide-push' },
  { id:'pt-003', category:'page-transitions', name:'Scale In', desc:'New page scales from center on enter', tier:'free', formats:['CSS','transform'], difficulty:'intermediate', preview:'scale-in' },
  { id:'pt-004', category:'page-transitions', name:'Curtain Wipe', desc:'Color curtain wipes across screen', tier:'premium', formats:['CSS','JS','clip-path'], difficulty:'advanced', preview:'curtain' },
  { id:'pt-005', category:'page-transitions', name:'Morph Circle', desc:'Expanding circle reveals next page', tier:'premium', formats:['CSS','clip-path','JS'], difficulty:'advanced', preview:'morph-circle' },
  { id:'pt-006', category:'page-transitions', name:'Pixel Dissolve', desc:'Canvas pixel-by-pixel dissolve transition', tier:'premium', formats:['Canvas','JS'], difficulty:'expert', preview:'dissolve' },

  // ═══════════════════════════════════════════════
  // CATEGORY 10: SVG ANIMATIONS
  // ═══════════════════════════════════════════════
  { id:'sv-001', category:'svg', name:'Morphing Blob', desc:'Organic SVG path morphing animation', tier:'free', formats:['SVG','CSS'], difficulty:'intermediate', preview:'blob' },
  { id:'sv-002', category:'svg', name:'Path Drawing', desc:'Stroke-dashoffset path draw on load', tier:'free', formats:['SVG','CSS'], difficulty:'intermediate', preview:'path-draw' },
  { id:'sv-003', category:'svg', name:'Icon Morph', desc:'SVG icon morphs between two shapes', tier:'premium', formats:['SVG','JS'], difficulty:'advanced', preview:'icon-morph' },
  { id:'sv-004', category:'svg', name:'Animated Logo', desc:'Stroke-animated logo reveal sequence', tier:'premium', formats:['SVG','CSS','@keyframes'], difficulty:'advanced', preview:'logo-anim' },
  { id:'sv-005', category:'svg', name:'Wave SVG Divider', desc:'Animated wavy section divider', tier:'free', formats:['SVG','CSS'], difficulty:'beginner', preview:'wave-divider' },
  { id:'sv-006', category:'svg', name:'Fluid Shapes', desc:'Continuously morphing fluid organic shapes', tier:'premium', formats:['SVG','JS','Bezier'], difficulty:'expert', preview:'fluid' },

  // ═══════════════════════════════════════════════
  // CATEGORY 11: CANVAS & 2D
  // ═══════════════════════════════════════════════
  { id:'cv-001', category:'canvas-2d', name:'Fireworks', desc:'Interactive fireworks on click', tier:'free', formats:['Canvas','JS'], difficulty:'intermediate', preview:'fireworks' },
  { id:'cv-002', category:'canvas-2d', name:'Confetti Burst', desc:'Physics-based coloured confetti shower', tier:'free', formats:['Canvas','JS'], difficulty:'intermediate', preview:'confetti' },
  { id:'cv-003', category:'canvas-2d', name:'Cloth Simulation', desc:'Mouse-interactive cloth physics simulation', tier:'premium', formats:['Canvas','JS','Physics'], difficulty:'expert', preview:'cloth' },
  { id:'cv-004', category:'canvas-2d', name:'Fluid Simulation', desc:'Real-time fluid dynamics on canvas', tier:'premium', formats:['Canvas','JS','WebGL'], difficulty:'expert', preview:'fluid-sim' },
  { id:'cv-005', category:'canvas-2d', name:'Fractal Tree', desc:'Animated recursive fractal tree growth', tier:'premium', formats:['Canvas','JS','Recursion'], difficulty:'advanced', preview:'fractal' },

  // ═══════════════════════════════════════════════
  // CATEGORY 12: MICRO-INTERACTIONS
  // ═══════════════════════════════════════════════
  { id:'mi-001', category:'micro', name:'Toggle Switch', desc:'Smooth animated toggle with spring', tier:'free', formats:['CSS','JS'], difficulty:'beginner', preview:'toggle' },
  { id:'mi-002', category:'micro', name:'Like Button Pop', desc:'Heart pop animation on like', tier:'free', formats:['CSS','JS'], difficulty:'beginner', preview:'like' },
  { id:'mi-003', category:'micro', name:'Checkbox Check', desc:'Custom animated SVG checkbox', tier:'free', formats:['SVG','CSS'], difficulty:'beginner', preview:'checkbox' },
  { id:'mi-004', category:'micro', name:'Dropdown Cascade', desc:'Stagger-animated dropdown menu items', tier:'free', formats:['CSS','JS'], difficulty:'intermediate', preview:'dropdown' },
  { id:'mi-005', category:'micro', name:'Tooltip Float', desc:'Floating tooltip with smart positioning', tier:'free', formats:['CSS','JS'], difficulty:'intermediate', preview:'tooltip' },
  { id:'mi-006', category:'micro', name:'Rating Stars', desc:'Animated star rating interaction', tier:'free', formats:['CSS','JS'], difficulty:'beginner', preview:'stars-rating' },

  // ═══════════════════════════════════════════════
  // CATEGORY 13: 3D CSS
  // ═══════════════════════════════════════════════
  { id:'3d-001', category:'css-3d', name:'3D Cube', desc:'Rotating 3D CSS cube with faces', tier:'free', formats:['CSS','perspective','rotateX/Y'], difficulty:'intermediate', preview:'cube' },
  { id:'3d-002', category:'css-3d', name:'3D Carousel', desc:'Cylindrical 3D card carousel', tier:'premium', formats:['CSS','JS','3D transform'], difficulty:'advanced', preview:'carousel-3d' },
  { id:'3d-003', category:'css-3d', name:'Folding Card', desc:'Card folds open like a book', tier:'premium', formats:['CSS','perspective','rotateY'], difficulty:'advanced', preview:'fold' },
  { id:'3d-004', category:'css-3d', name:'Depth Layers', desc:'Layered parallax depth on mouse move', tier:'premium', formats:['JS','CSS','translateZ'], difficulty:'advanced', preview:'depth' },

  // ═══════════════════════════════════════════════
  // CATEGORY 14: GLASSMORPHISM & NEUMORPHISM
  // ═══════════════════════════════════════════════
  { id:'gl-001', category:'glass-neu', name:'Frosted Glass Card', desc:'backdrop-filter blur glass effect', tier:'free', formats:['CSS','backdrop-filter'], difficulty:'beginner', preview:'glass-card' },
  { id:'gl-002', category:'glass-neu', name:'Neumorphic Button', desc:'Soft shadow neumorphic UI button', tier:'free', formats:['CSS','box-shadow'], difficulty:'beginner', preview:'neu-btn' },
  { id:'gl-003', category:'glass-neu', name:'Glass Modal', desc:'Full frosted glass overlay modal', tier:'free', formats:['CSS','JS'], difficulty:'intermediate', preview:'glass-modal' },
  { id:'gl-004', category:'glass-neu', name:'Aurora Glass', desc:'Aurora-coloured frosted glass panel', tier:'premium', formats:['CSS','@keyframes','backdrop-filter'], difficulty:'intermediate', preview:'aurora-glass' },

  // ═══════════════════════════════════════════════
  // CATEGORY 15: CURSOR EFFECTS
  // ═══════════════════════════════════════════════
  { id:'cu-001', category:'cursor', name:'Custom Cursor', desc:'Smooth trailing custom cursor', tier:'free', formats:['JS','CSS'], difficulty:'beginner', preview:'cursor' },
  { id:'cu-002', category:'cursor', name:'Magnetic Cursor', desc:'Cursor attracted to interactive elements', tier:'free', formats:['JS','CSS'], difficulty:'intermediate', preview:'magnetic-cursor' },
  { id:'cu-003', category:'cursor', name:'Ink Cursor Trail', desc:'Ink drop trail following cursor', tier:'premium', formats:['Canvas','JS'], difficulty:'advanced', preview:'ink-trail' },
  { id:'cu-004', category:'cursor', name:'Spotlight Cursor', desc:'Radial spotlight follows cursor on dark bg', tier:'premium', formats:['JS','CSS','radial-gradient'], difficulty:'intermediate', preview:'spotlight' },

  // ═══════════════════════════════════════════════
  // CATEGORY 16: MODALS & OVERLAYS
  // ═══════════════════════════════════════════════
  { id:'mo-001', category:'modals', name:'Fade Scale Modal', desc:'Modal fades in and scales from centre', tier:'free', formats:['CSS','JS'], difficulty:'beginner', preview:'modal-scale' },
  { id:'mo-002', category:'modals', name:'Slide-Up Sheet', desc:'Bottom-sheet slides up (mobile-style)', tier:'free', formats:['CSS','JS'], difficulty:'intermediate', preview:'sheet' },
  { id:'mo-003', category:'modals', name:'Curtain Overlay', desc:'Full-screen curtain reveal overlay', tier:'premium', formats:['CSS','JS','clip-path'], difficulty:'advanced', preview:'curtain-modal' },

  // ═══════════════════════════════════════════════
  // CATEGORY 17: NAVIGATION
  // ═══════════════════════════════════════════════
  { id:'nv-001', category:'navigation', name:'Animated Hamburger', desc:'Hamburger icon morphs to X on open', tier:'free', formats:['CSS','JS'], difficulty:'beginner', preview:'hamburger' },
  { id:'nv-002', category:'navigation', name:'Underline Slide', desc:'Active nav underline slides between items', tier:'free', formats:['JS','CSS'], difficulty:'intermediate', preview:'nav-underline' },
  { id:'nv-003', category:'navigation', name:'Mega Menu Reveal', desc:'Full-width mega menu with stagger', tier:'premium', formats:['CSS','JS'], difficulty:'advanced', preview:'mega-menu' },
  { id:'nv-004', category:'navigation', name:'Side Drawer', desc:'Animated side-navigation drawer', tier:'free', formats:['CSS','JS'], difficulty:'intermediate', preview:'drawer' },

  // ═══════════════════════════════════════════════
  // CATEGORY 18: NOTIFICATIONS
  // ═══════════════════════════════════════════════
  { id:'no-001', category:'notifications', name:'Toast Notification', desc:'Slide-in toast with auto-dismiss', tier:'free', formats:['CSS','JS'], difficulty:'beginner', preview:'toast' },
  { id:'no-002', category:'notifications', name:'Badge Pulse', desc:'Notification badge with pulse ring', tier:'free', formats:['CSS'], difficulty:'beginner', preview:'badge-pulse' },
  { id:'no-003', category:'notifications', name:'Alert Shake', desc:'Error alert shakes to draw attention', tier:'free', formats:['CSS','@keyframes'], difficulty:'beginner', preview:'shake' },

  // ═══════════════════════════════════════════════
  // CATEGORY 19: IMAGES & MEDIA
  // ═══════════════════════════════════════════════
  { id:'im-001', category:'images', name:'Lazy Load Blur', desc:'Blur-to-sharp lazy image load reveal', tier:'free', formats:['JS','CSS','IntersectionObserver'], difficulty:'beginner', preview:'lazy-blur' },
  { id:'im-002', category:'images', name:'Gallery Masonry Fade', desc:'Masonry grid with staggered fade-in', tier:'premium', formats:['JS','CSS','Grid'], difficulty:'advanced', preview:'masonry' },
  { id:'im-003', category:'images', name:'Image Distortion', desc:'WebGL vertex distortion on hover', tier:'premium', formats:['WebGL','GLSL'], difficulty:'expert', preview:'distortion' },
  { id:'im-004', category:'images', name:'Ken Burns Effect', desc:'Slow zoom and pan on images', tier:'free', formats:['CSS','@keyframes'], difficulty:'beginner', preview:'ken-burns' },

  // ═══════════════════════════════════════════════
  // CATEGORY 20: FORMS & INPUTS
  // ═══════════════════════════════════════════════
  { id:'fo-001', category:'forms', name:'Floating Label', desc:'Label floats above on focus', tier:'free', formats:['CSS','JS'], difficulty:'beginner', preview:'float-label' },
  { id:'fo-002', category:'forms', name:'Input Shake Validation', desc:'Input shakes on invalid submission', tier:'free', formats:['CSS','JS'], difficulty:'beginner', preview:'input-shake' },
  { id:'fo-003', category:'forms', name:'Submit to Success', desc:'Submit button morphs to checkmark', tier:'premium', formats:['CSS','JS','clip-path'], difficulty:'advanced', preview:'submit-success' },
  { id:'fo-004', category:'forms', name:'OTP Input Animation', desc:'Stagger-animated OTP input boxes', tier:'free', formats:['CSS','JS'], difficulty:'intermediate', preview:'otp' },

  // ═══════════════════════════════════════════════
  // CATEGORY 21: CHARTS & DATA VIZ
  // ═══════════════════════════════════════════════
  { id:'dv-001', category:'data-viz', name:'Bar Chart Animate', desc:'Bars grow from zero on load', tier:'free', formats:['CSS','JS'], difficulty:'beginner', preview:'bar-chart' },
  { id:'dv-002', category:'data-viz', name:'Pie Chart Draw', desc:'SVG arc draws pie slice by slice', tier:'premium', formats:['SVG','JS'], difficulty:'advanced', preview:'pie-chart' },
  { id:'dv-003', category:'data-viz', name:'Line Chart Trace', desc:'Line chart traces from left to right', tier:'premium', formats:['SVG','CSS','stroke-dashoffset'], difficulty:'advanced', preview:'line-chart' },
  { id:'dv-004', category:'data-viz', name:'Radial Gauge', desc:'Animated radial progress gauge', tier:'premium', formats:['SVG','JS'], difficulty:'advanced', preview:'gauge' },
];

// Category metadata
const categories = [
  { id:'motion-physics',  label:'Motion & Physics',   icon:'⚡', count: animations.filter(a=>a.category==='motion-physics').length },
  { id:'text-effects',    label:'Text Effects',        icon:'✍', count: animations.filter(a=>a.category==='text-effects').length },
  { id:'hover-effects',   label:'Hover Effects',       icon:'🖱', count: animations.filter(a=>a.category==='hover-effects').length },
  { id:'loading',         label:'Loading States',      icon:'⏳', count: animations.filter(a=>a.category==='loading').length },
  { id:'scroll',          label:'Scroll Animations',   icon:'📜', count: animations.filter(a=>a.category==='scroll').length },
  { id:'background',      label:'Background FX',       icon:'🌌', count: animations.filter(a=>a.category==='background').length },
  { id:'buttons',         label:'Buttons & CTAs',      icon:'🔘', count: animations.filter(a=>a.category==='buttons').length },
  { id:'cards',           label:'Cards',               icon:'🃏', count: animations.filter(a=>a.category==='cards').length },
  { id:'page-transitions',label:'Page Transitions',    icon:'🔄', count: animations.filter(a=>a.category==='page-transitions').length },
  { id:'svg',             label:'SVG Animations',      icon:'⬡', count: animations.filter(a=>a.category==='svg').length },
  { id:'canvas-2d',       label:'Canvas & 2D',         icon:'🎨', count: animations.filter(a=>a.category==='canvas-2d').length },
  { id:'micro',           label:'Micro-Interactions',  icon:'✨', count: animations.filter(a=>a.category==='micro').length },
  { id:'css-3d',          label:'CSS 3D',              icon:'📦', count: animations.filter(a=>a.category==='css-3d').length },
  { id:'glass-neu',       label:'Glass & Neumorphism', icon:'🪟', count: animations.filter(a=>a.category==='glass-neu').length },
  { id:'cursor',          label:'Cursor Effects',      icon:'🖱', count: animations.filter(a=>a.category==='cursor').length },
  { id:'modals',          label:'Modals & Overlays',   icon:'🪟', count: animations.filter(a=>a.category==='modals').length },
  { id:'navigation',      label:'Navigation',          icon:'🧭', count: animations.filter(a=>a.category==='navigation').length },
  { id:'notifications',   label:'Notifications',       icon:'🔔', count: animations.filter(a=>a.category==='notifications').length },
  { id:'images',          label:'Images & Media',      icon:'🖼', count: animations.filter(a=>a.category==='images').length },
  { id:'forms',           label:'Forms & Inputs',      icon:'📝', count: animations.filter(a=>a.category==='forms').length },
  { id:'data-viz',        label:'Charts & Data Viz',   icon:'📊', count: animations.filter(a=>a.category==='data-viz').length },
];

module.exports = { animations, categories };
