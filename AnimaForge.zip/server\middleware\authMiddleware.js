/**
 * AnimaForge — JWT Auth Middleware
 * Verifies Bearer tokens and attaches user to req
 */
'use strict';

const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret-change-in-production';

// ── Verify JWT Token ──────────────────────────────────────
function verifyToken(req, res, next) {
  try {
    // Check Authorization header first, then HttpOnly cookie
    let token = null;

    const authHeader = req.headers['authorization'];
    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.slice(7);
    } else if (req.cookies && req.cookies.af_token) {
      token = req.cookies.af_token;
    }

    if (!token) {
      return res.status(401).json({
        error: 'Authentication required',
        code: 'NO_TOKEN',
      });
    }

    const decoded = jwt.verify(token, JWT_SECRET, {
      algorithms: ['HS256'],
      issuer: 'animaforge',
      audience: 'animaforge-client',
    });

    req.user = decoded;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Session expired. Please sign in again.', code: 'TOKEN_EXPIRED' });
    }
    if (err.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Invalid token.', code: 'INVALID_TOKEN' });
    }
    return res.status(401).json({ error: 'Authentication failed.', code: 'AUTH_FAILED' });
  }
}

// ── Optional Auth (attach user if token exists, don't fail) ──
function optionalAuth(req, res, next) {
  try {
    let token = null;
    const authHeader = req.headers['authorization'];
    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.slice(7);
    } else if (req.cookies && req.cookies.af_token) {
      token = req.cookies.af_token;
    }

    if (token) {
      const decoded = jwt.verify(token, JWT_SECRET, {
        algorithms: ['HS256'],
        issuer: 'animaforge',
        audience: 'animaforge-client',
      });
      req.user = decoded;
    }
  } catch {
    // silently ignore — optional
    req.user = null;
  }
  next();
}

// ── Require Premium ───────────────────────────────────────
function requirePremium(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required', code: 'NO_TOKEN' });
  }
  if (!req.user.isPremium) {
    return res.status(403).json({
      error: 'Premium subscription required',
      code: 'PREMIUM_REQUIRED',
      upgradeUrl: '/upgrade',
    });
  }
  next();
}

// ── Sign JWT ──────────────────────────────────────────────
function signToken(payload) {
  return jwt.sign(
    {
      ...payload,
      iss: 'animaforge',
      aud: 'animaforge-client',
    },
    JWT_SECRET,
    {
      algorithm: 'HS256',
      expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    }
  );
}

// ── Refresh Token (extend session) ───────────────────────
function refreshToken(req, res, next) {
  try {
    const token = req.cookies?.af_token;
    if (!token) return next();

    const decoded = jwt.verify(token, JWT_SECRET, {
      algorithms: ['HS256'],
      issuer: 'animaforge',
      audience: 'animaforge-client',
    });

    // Refresh if less than 1 day remaining
    const now = Math.floor(Date.now() / 1000);
    if (decoded.exp - now < 86400) {
      const { iat, exp, iss, aud, ...payload } = decoded;
      const newToken = signToken(payload);
      res.cookie('af_token', newToken, cookieOptions());
    }

    req.user = decoded;
    next();
  } catch {
    next();
  }
}

function cookieOptions() {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    path: '/',
  };
}

module.exports = { verifyToken, optionalAuth, requirePremium, signToken, cookieOptions, refreshToken };
